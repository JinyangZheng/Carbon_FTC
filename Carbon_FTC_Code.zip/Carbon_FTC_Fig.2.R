###
### Carbon_FTC_Fig.2
###
#MBC_R plot processing
{
  cols <- c("Thaw" = "#e994ae","Freeze" = "#a0bff6")
  MBC_R <- 
    ggplot(MBC_R.data.,
           aes(x=x.axis,  
               y=mean,  
               color=ForT
           ))+
    geom_linerange(
      aes(ymin = mean-sd,
          ymax = mean+sd,
          color = ForT),
      linewidth = 0.7 ) +
    
    geom_point(
      aes(color = ForT),
      size = 3) +
    
    theme_bw()+ 
    scale_color_manual(values = cols) +
    theme(panel.grid=element_blank(),
          axis.text = element_text(size=13,color='black'),
          axis.title = element_text(size=15),
          strip.background = element_blank(),
          strip.text = element_blank(),
          panel.border = element_rect(size=1),
          axis.ticks = element_line(size=1))+  
    scale_y_continuous(limit=c(0,8),breaks = c(1,4,7))+
    labs(x=NULL,y='Rs (ug CO2-C g-1 SOC h-1)')
}
#Enz.deg plot processing
{
  Enz.deg <- 
    ggplot(Enz.deg.data.,
           aes(x=FTC.type,y=mean))+
    geom_linerange(
      aes(ymin = mean-sd,ymax = mean+sd),
      linewidth = 0.7) +
    geom_point(
      aes(),
      size = 3) +
    theme_bw()+ 
    theme(panel.grid=element_blank(),
          axis.text = element_text(size=13,color='black'),
          axis.title = element_text(size=15),
          strip.background = element_blank(),
          strip.text = element_blank(),
          panel.border = element_rect(size=1),
          axis.ticks = element_line(size=1))+
    scale_y_continuous(limit=c(0,0.8),breaks = c(0.1,0.4,0.7))+
    labs(x=NULL,y='EEA (ug C g-1 SOC h-1)')
}
#DOC plot processing
{

  DOC <- 
    ggplot(DOC.data.,
           aes(x=FTC.type,y=mean))+
    geom_linerange(
      aes(ymin = mean-sd,
          ymax = mean+sd),
      linewidth = 0.7 
      ) +
    geom_point(
      aes(),
      size = 3) +
    theme_bw()+ 
    theme(panel.grid=element_blank(),
          axis.text = element_text(size=13,color='black'),
          axis.title = element_text(size=15),
          strip.background = element_blank(),
          strip.text = element_blank(),
          panel.border = element_rect(size=1),
          axis.ticks = element_line(size=1))+
    scale_y_continuous(limit=c(10000,31000),breaks = c(12000,21000,30000))+
    labs(x=NULL,y='DOC (%)')
}
#MBC plot processing
{
  MBC <- 
    ggplot(MBC.data.,
           aes(x=FTC.type,  y=mean))+
    geom_linerange(
      aes(ymin = mean-sd,
          ymax = mean+sd),
      linewidth = 0.7) +
    geom_point(aes(),size = 3) +
    theme_bw()+ 
    theme(panel.grid=element_blank(),
          axis.text = element_text(size=13,color='black'),
          axis.title = element_text(size=15),
          strip.background = element_blank(),
          strip.text = element_blank(),
          panel.border = element_rect(size=1),
          axis.ticks = element_line(size=1))+ 
    scale_y_continuous(limit=c(-1000,49000),breaks = c(5000,24000,44000))+
    labs(x=NULL,y='MBC (%)')
}
#Four figures combine
{
plot_all <- ggarrange(MBC_R,Enz.deg,DOC,MBC,ncol=1,nrow=4,align='hv')
ggsave('./Fig.2.pdf',plot_all,dpi=300,width=7, height=14)
}
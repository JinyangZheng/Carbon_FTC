#LFLT time
{
  freeze_time<- 288
  thaw_time <- 288
  #Stage 1
  temp_one_cycle <- c(rep(-10,freeze_time),rep(10,thaw_time))
  t <- 2.5
  var.t <- as.integer(10/t)
  temp_one_cycle[1:(2*var.t)] <- c(10,7.5,5,2.5,0,-2.5,-5,-7.5)
  temp_one_cycle[(freeze_time+1):(freeze_time+2*var.t)] <- c(-10,-7.5,-5,-2.5,0,2.5,5,7.5)
  
  stage1_time_temp <- data.frame(
    time=c(0,1:(length(rep(temp_one_cycle,4))-1)),
    temp=rep(temp_one_cycle,4)
  )
  #Stage 2
  stage2_time_temp <- data.frame(
    time=c( (length(rep(temp_one_cycle,4))):4608
    ),
    temp=rep(-10,length((length(rep(temp_one_cycle,4))):4608)
    )
  )
  stage2_time_temp$temp[1:(2*var.t)] <- c(10,7.5,5,2.5,0,-2.5,-5,-7.5)
  #Stage 3
  temp_one_cycle <- c(rep(-10,freeze_time),rep(10,thaw_time))
  t <- 2.5
  var.t <- as.integer(10/t)
  temp_one_cycle[1:(2*var.t)] <- c(10,7.5,5,2.5,0,-2.5,-5,-7.5)
  temp_one_cycle[(freeze_time+1):(freeze_time+2*var.t)] <- c(-10,-7.5,-5,-2.5,0,2.5,5,7.5)
  stage3_time_temp <- data.frame(
    time=c(4609:5760),
    temp=rep(temp_one_cycle,2)
  )
  stage3_time_temp$temp[1:(2*var.t)] <- -10
  ###rbind
  stage12 <- rbind(stage1_time_temp,stage2_time_temp)
  LFLT_stage123 <- rbind(stage12,stage3_time_temp)
}
###
### Full model
###
{
  Flux_all <- function(
    V,temp,
    DOC.uptake.K,
    DOC.uptake.Ea,
    Enz.P,
    Enz.D,
    MBC.D,
    MBC.D.ice,
    NOC.deg.K,
    NOC.deg.Ea,
    gas,
    Csor1,Csor2,r1,r2,
    CUE,f,f1,f2,
    P.DOC.above0,
    P.NOC.above0,
    MBC1,MBC2,
    Enz1,Enz2,
    DOC1,DOC2,
    NOC1,NOC2,
    P.DOC,P.NOC,
    temp.cor,
    temp.cor.ice,
    temp.cor.increase
  ){
    ###
    ###MBC1
    ###
    {
      # Model above 0 °C
      # 1. Active at all temperatures, without physical isolation, involved in DOC uptake, mortality, and enzyme production.
      same1 = V[1] * DOC1 / (DOC.uptake.K+DOC1) * exp(-(DOC.uptake.Ea)/(gas*(temp+273)))
      same2 = V[1] * DOC2 / (DOC.uptake.K+DOC2) * exp(-(DOC.uptake.Ea)/(gas*(temp+273)))
      
      # 1. MBC1.1
      ### Microbial uptake of DOC
      MBC1_U.1 = MBC1 * same1   # MM function and Arrhenius equation
      
      ### Microbial mortality
      MBC1_D = MBC1 * MBC.D   
      
      ### Microbial mortality induced by freezing
      MBC1_D.ice = MBC1 * MBC.D.ice * temp.cor.ice
      
      ### Enzyme production
      Enz1_P = MBC1 * Enz.P   
      
      ### Microbial respiration
      MBC1_R.1 = MBC1_U.1 * (1 - CUE)  # Fraction used for respiration multiplied by DOC taken up by MBC
      
      ### Microbial growth
      MBC1_G.1 = MBC1_U.1 * CUE  # Fraction used for growth multiplied by DOC taken up by MBC
      
      # Model above 0 °C
      # 1. Active at all temperatures, with physical isolation, involved in DOC uptake, mortality, and enzyme production.
      ### Microbial uptake of DOC
      MBC1_U.2 = MBC1 * same2  * temp.cor    # MM function and Arrhenius equation
      
      ### Microbial respiration
      MBC1_R.2 = MBC1_U.2 * (1 - CUE)  # Fraction used for respiration multiplied by DOC taken up by MBC
      
      ### Microbial growth
      MBC1_G.2 = MBC1_U.2 * CUE  # Fraction used for growth multiplied by DOC taken up by MBC
      
      MBC1_R = MBC1_R.1 + MBC1_R.2
      MBC1_G = MBC1_G.1 + MBC1_G.2
    }
    
    ###
    ###MBC2
    ###
    {
      # 2. Dormant below 0 °C, with no DOC uptake or enzyme production, only involved in mortality.
      # 2. MBC2
      
      ### Microbial uptake of DOC
      MBC2_U.1 = MBC2 * same1 * temp.cor   # MM function and Arrhenius equation
      
      ### Microbial mortality
      MBC2_D = MBC2 * MBC.D   * temp.cor
      
      ### Enzyme production
      Enz2_P = MBC2 * Enz.P   * temp.cor
      
      ### Microbial respiration
      MBC2_R.1 = MBC2_U.1 * (1 - CUE)  # Fraction used for respiration multiplied by DOC taken up by MBC
      
      ### Microbial growth
      MBC2_G.1 = MBC2_U.1 * CUE  # Fraction used for growth multiplied by DOC taken up by MBC
      
      # 2. Dormant below 0 °C, with no DOC uptake or enzyme production, only involved in mortality.
      # 2. MBC2
      
      ### Microbial uptake of DOC
      MBC2_U.2 = MBC2 * same2 * temp.cor   # MM function and Arrhenius equation
      
      ### Microbial respiration
      MBC2_R.2 = MBC2_U.2 * (1 - CUE)  # Fraction used for respiration multiplied by DOC taken up by MBC
      
      ### Microbial growth
      MBC2_G.2 = MBC2_U.2 * CUE  # Fraction used for growth multiplied by DOC taken up by MBC
      
      MBC2_R = MBC2_R.1 + MBC2_R.2
      MBC2_G = MBC2_G.1 + MBC2_G.2
    }
    
    ###
    ### ENZ1
    ###
    {
      ### Enzymatic degradation of NOC into DOC
      # 1. Active at all temperatures, without physical isolation, involved in DOC production and decay.
      
      same3 = V[2] * NOC1/(NOC.deg.K + NOC1) * exp(-(NOC.deg.Ea[1])/(gas*(temp+273)))
      same4 = V[2] * NOC2/(NOC.deg.K + NOC2) * exp(-(NOC.deg.Ea[1])/(gas*(temp+273)))
      
      # 1. Enz to NOC1
      Enz1_deg.1 = Enz1 * same3     # MM function and Arrhenius equation
      
      # 2. Active at all temperatures, with physical isolation, involved in DOC production and decay.
      # 2. Enz to NOC2
      Enz1_deg.2 = Enz1 * same4 * temp.cor     # MM function and Arrhenius equation
      
      ###
      Enz1_deg = Enz1_deg.1 + Enz1_deg.2
      
      ### Enzyme decay
      Enz1_D = Enz1 * Enz.D  
    }
    
    ###
    ### ENZ2
    ###
    {
      ### Enzymatic degradation of NOC into DOC
      # 1. Inactive below 0 °C, without physical isolation, involved in DOC production and decay.
      
      # 1. Enz to NOC1
      Enz2_deg.1 = Enz2 * same3 * temp.cor     # MM function and Arrhenius equation
      
      # 2. Enz to NOC2
      Enz2_deg.2 = Enz2 * same4 * temp.cor     # MM function and Arrhenius equation
      
      ###
      Enz2_deg = Enz2_deg.1 + Enz2_deg.2
      
      ### Enzyme decay
      Enz2_D = Enz2 * Enz.D  
      
      Enz_deg = Enz1_deg + Enz2_deg
      Enz_D = Enz1_D + Enz2_D
    }
    
    ### Sorption between available organic carbon and organic carbon
    {
      sorption.DOC1 =  Csor1 * DOC1
      sorption.DOC2 =  Csor1 * DOC2 * temp.cor # Physically isolated and unavailable for sorption
      
      sorption.A.DOC = sorption.DOC1 + sorption.DOC2
      
      sorption.NOC1 =  Csor2 * NOC1
      sorption.NOC2 =  Csor2 * NOC2 * temp.cor # Physically isolated and unavailable for sorption
      
      sorption.A.NOC = sorption.NOC1 + sorption.NOC2
      
      ### Desorption between protected organic carbon and available organic carbon
      ### Transfer from P.DOC to A.DOC
      ### Transfer from P.NOC to A.NOC
      ### Desorption rate
      desorption.P.DOC = r1 * P.DOC
      desorption.P.NOC = r2 * P.NOC
    }
    
    ### Changes in carbon pools at different time points
    
    ### Changes in microbial carbon pools
    dMBC1 =  MBC1_G -            # Input - DOC used by microbes
      (MBC1_D + MBC1_D.ice + Enz1_P)    # Output - dead microbial biomass plus microbial biomass allocated to enzymes
    
    dMBC2 = MBC2_G -            # Input - DOC used by microbes
      (MBC2_D + Enz2_P)    # Output - dead microbial biomass plus microbial biomass allocated to enzymes
    
    dMBC = dMBC1 + dMBC2
    
    ### Changes in enzyme pools
    dEnz = Enz1_P + Enz2_P - Enz_D
    dEnz1 = Enz1_P - Enz1_D
    dEnz2 = Enz2_P - Enz2_D
    
    # Aggregate breakdown release
    Break.DOC = P.DOC * P.DOC.above0 * temp.cor.increase
    Break.NOC = P.NOC * P.NOC.above0 * temp.cor.increase
    
    ### Change in the protected DOC pool
    dP.DOC = sorption.A.DOC  -  # Input
      (Break.DOC + desorption.P.DOC)  # Output
    
    ### Change in the protected NOC pool
    dP.NOC = sorption.A.NOC -  # Input
      (Break.NOC + desorption.P.NOC)  # Output
    
    ### Change in the available DOC pool
    dDOC1 =   (MBC1_D + MBC2_D + MBC1_D.ice)*f*(1-f1) +            # Input
      (Enz_deg*(1-f1)) +                    # Input
      (Enz_D*(1-f1)) +                      # Input
      (Break.DOC + desorption.P.DOC)*(1-f1) - # Input
      (MBC1_U.1 + MBC2_U.1)-  # Output
      sorption.DOC1   # Output
    
    ### Change in the physically isolated available DOC pool
    dDOC2 =  (MBC1_D + MBC2_D + MBC1_D.ice)*f*f1 +        # Input
      Enz_deg*f1 +                 # Input
      Enz_D*f1 +                   # Input
      (Break.DOC + desorption.P.DOC)*f1 - # Input
      (MBC1_U.2 + MBC2_U.2)-      # Output
      sorption.DOC2         # Output
    
    dDOC = dDOC1 + dDOC2 + dP.DOC
    
    ### Change in the available NOC pool
    dNOC1 = (MBC1_D + MBC2_D + MBC1_D.ice)*(1-f)*(1-f2) +            # Input
      (Break.NOC + desorption.P.NOC)*(1-f2)  -  # Input
      (Enz_deg)*(1-f2) - sorption.NOC1           # Output
    
    ### Change in the physically isolated available NOC pool
    dNOC2 = (MBC1_D + MBC2_D + MBC1_D.ice)*(1-f)*f2 +            # Input
      (Break.NOC + desorption.P.NOC)*f2  -  # Input
      (Enz_deg)*f2 - sorption.NOC2                  # Output
    
    dNOC = dNOC1 + dNOC2 + dP.NOC
    
    ### Microbial respiration
    MBC_R = MBC1_R + MBC2_R
    
    ### Enzymatic degradation of SOC
    Enz.deg = Enz_deg
    
    # Output
    c(dMBC,    # Microbial biomass
      dMBC1,   # Microbial biomass, microbes active at all temperatures
      dMBC2,   # Microbial biomass, microbes active only above 0 °C
      dEnz,    # Daily change in total enzymes
      dEnz1,   #
      dEnz2,   #
      
      dP.DOC,
      dP.NOC,
      
      dDOC1,    # Daily change in DOC, constrained by measured values
      dDOC2,
      dDOC,
      
      dNOC1,    # Daily change in NOC
      dNOC2,    
      dNOC,
      
      MBC_R,    # Daily microbial respiration, constrained by measured values
      Enz.deg  # Enzymatic degradation of SOC, constrained by measured values
    )
  }
  #Prepare function
  {
    #Temp~time
    thaw_to_freeze <- function(x){10 - t * (x)}
    freeze_to_thaw <- function(x){-10 + t * (x)}
    # half-saturation constant of DOC
    T_correct.DOC.uptake.K <- function(temp,Slope_DOC.uptake.K,intercept_DOC.uptake.K) { Slope_DOC.uptake.K * temp + intercept_DOC.uptake.K  }
    # half-saturation constant of SOC
    T_correct.NOC.deg.K <- function(temp,Slope_NOC.deg.K,intercept_NOC.deg.K) { Slope_NOC.deg.K * temp + intercept_NOC.deg.K  }
    # CUE
    T_correct.CUE <- function(temp,Slope_CUE,intercept_CUE){ Slope_CUE * temp + intercept_CUE } 
    #breakdown coefficient of DOC
    T_correct.above0.P.DOC <- function(temp,Slope_above0.P.DOC,intercept_P.DOC){ Slope_above0.P.DOC * temp + intercept_P.DOC } 
    #breakdown coefficient of SOC
    T_correct.above0.P.NOC <- function(temp,Slope_above0.P.NOC,intercept_P.NOC){ Slope_above0.P.NOC * temp + intercept_P.NOC } 
    #sorption
    T_correct.C.sor1 <- function(temp,Slope_C.sor1,intercept_C.sor1){ Slope_C.sor1 * temp + intercept_C.sor1 } 
    T_correct.C.sor2 <- function(temp,Slope_C.sor2,intercept_C.sor2){ Slope_C.sor2 * temp + intercept_C.sor2 } 
    #desorption
    T_correct.r1 <- function(temp,Slope_r1,intercept_r1){ Slope_r1 * temp + intercept_r1 } 
    T_correct.r2 <- function(temp,Slope_r2,intercept_r2){ Slope_r2 * temp + intercept_r2 } 
    #dormancy
    T_correct <- function(temp){ifelse(temp < 0, 0, 1)}
    #For freeze death
    T_correct.ice <- function(temp){ifelse(temp < 0, 1, 0)}
    #For aggregate break release
    T_correct_increase <- function(temp) {
      dtemp <- c(0, diff(temp))
      mark <- ifelse(temp >= 0 & temp <= 10 & dtemp > 0, 1, 0)
      return(mark)
    }
  }
  
  Model.all.T2 <- function(x,MB0,DOC0,CUE10) {
    
    #parameters input
    {
      ###
      T0 <-  1e+6			        # Total SOC 106 ug==1g
      gas <- 8.314
      
      
      M0 <- MB0        # Microbial biomass carbon, measured value
      f.enz <- .02     # Initial enzyme fraction, set to 2%; kept identical across the four regimes for the same soil
      Enz0 <- M0 * f.enz      # Initial enzyme pool
      C0 <- T0 - MB0 - Enz0   # Carbon pool after excluding microbial biomass and enzymes, i.e., DOC + SOC
      
      # Ratio of available DOC to protected DOC
      f.A.DOC_P.DOC <- 0.5    # Available DOC fraction, set to 40–60%; kept identical across the four regimes for the same soil
      P.DOC.0 <- DOC0 * (1 - f.A.DOC_P.DOC)  # Protected DOC pool
      A.DOC.0 <- DOC0 * f.A.DOC_P.DOC        # Available DOC pool
      
      # Fraction of protected non-DOC carbon
      f.P.NOC <- 0.5   # Kept identical across the four regimes for the same soil
      P.NOC.0 <- (C0 - DOC0) * f.P.NOC       # Protected non-DOC carbon pool
      A.NOC.0 <- (C0 - DOC0) * (1 - f.P.NOC) # Available non-DOC carbon pool
      
      # Higher temperature promotes desorption
      # Lower temperature promotes adsorption
      
      ### DOC sorption
      C.sor1.10 <- x[1] 
      C.sor1.minus10 <- x[2]
      intercept_C.sor1 <- (C.sor1.10 + C.sor1.minus10) / 2  # Sorption coefficient
      Slope_C.sor1 <- (C.sor1.10 - C.sor1.minus10) / 20
      
      ### SOC sorption
      C.sor2.10 <- x[3] 
      C.sor2.minus10 <- x[4]
      intercept_C.sor2 <- (C.sor2.10 + C.sor2.minus10) / 2  # Sorption coefficient
      Slope_C.sor2 <- (C.sor2.10 - C.sor2.minus10) / 20
      
      ### DOC desorption
      r1.10 <- x[5] 
      r1.minus10 <- x[6] 
      intercept_r1 <- (r1.10 + r1.minus10) / 2  # Desorption coefficient
      Slope_r1 <- (r1.10 - r1.minus10) / 20     # Desorption coefficient
      
      ### SOC desorption
      r2.10 <- x[7]
      r2.minus10 <- x[8] 
      intercept_r2 <- (r2.10 + r2.minus10) / 2  # Desorption coefficient
      Slope_r2 <- (r2.10 - r2.minus10) / 20     # Desorption coefficient
      
      ###
      V <- exp(x[9:10])  # Maximum rate of microbial DOC uptake and enzyme-mediated NOC degradation
      DOC.uptake.Ea <- 47  # Activation energy for microbial DOC uptake
      NOC.deg.Ea <- 47     # Activation energy for enzyme-mediated NOC degradation
      f <- .2              # Fraction of dead microbial biomass converted to DOC
      
      # From −10 °C to 10 °C, Km decreases with increasing temperature, indicating enhanced activity
      
      ### MBC uptake of DOC
      DOC.uptake.K.10 <- A.DOC.0 * 0.2        # Kept identical across the four regimes for the same soil; set to 45–55%
      DOC.uptake.K.minus10 <- A.DOC.0 * 0.8   # Kept identical across the four regimes for the same soil; set to 55–60%
      intercept_DOC.uptake.K <- (DOC.uptake.K.10 + DOC.uptake.K.minus10) / 2  # Intercept of the half-saturation constant for microbial DOC uptake
      Slope_DOC.uptake.K <- (DOC.uptake.K.10 - DOC.uptake.K.minus10) / 20     # Slope of the half-saturation constant for microbial DOC uptake
      
      ### Enzyme-mediated NOC degradation
      NOC.deg.K.10 <- A.NOC.0 * 0.2        # Kept identical across the four regimes for the same soil; set to 45–55%
      NOC.deg.K.minus10 <- A.NOC.0 * 0.8   # Kept identical across the four regimes for the same soil; set to 55–60%
      intercept_NOC.deg.K <- (NOC.deg.K.10 + NOC.deg.K.minus10) / 2  # Intercept for enzyme-mediated NOC degradation
      Slope_NOC.deg.K <- (NOC.deg.K.10 - NOC.deg.K.minus10) / 20     # Slope for enzyme-mediated NOC degradation
      
      # Enzyme decay
      Enz.D <- exp(x[11])
      
      # Microbial physiological mortality
      MBC.D <- exp(x[12])
      
      # Microbial enzyme production
      Enz.P <- exp(x[13])
      
      # Microbial CUE
      CUE.10 <- CUE10       # Based on measured values; kept identical across the four regimes for the same soil
      CUE.minus10 <- x[14]  
      intercept_CUE <- (CUE.10 + CUE.minus10) / 2
      Slope_CUE <- (CUE.10 - CUE.minus10) / 20
      
      # Physical mechanism
      f1 <- x[15]   # Isolation coefficient of available DOC below 0 °C, set to 40–60%
      f2 <- f1      # Isolation coefficient of available SOC below 0 °C, set to 40–60%
      
      # Intercept of the breakdown coefficient for protected DOC
      intercept_P.DOC <- exp(x[16])
      
      # Calculate the slope from the intercept
      Slope_above0.P.DOC <- -(intercept_P.DOC / 10)
      
      # Intercept of the breakdown coefficient for protected NOC
      intercept_P.NOC <- exp(x[17])
      
      # Calculate the slope from the intercept
      Slope_above0.P.NOC <- -(intercept_P.NOC / 10)
      
      # Physiological mechanism
      dormancy.ratio <- x[18]   # Microbial dormancy fraction
      inactive.ratio <- x[19]   # Enzyme inactive fraction
      
      # Fraction of microbial mortality caused by ice formation
      MBC.D.ice <- exp(x[20])
    } 
    {     
      timesteps <- length(LFLT_stage123$temp)
      Cpools <- matrix(0, nrow = timesteps, ncol = 18)
      colnames(Cpools) <- c("Hour","Temp",
                            "MBC","MBC1","MBC2",
                            "Enz","Enz1","Enz2",
                            "P.DOC","P.NOC",
                            "DOC1","DOC2","DOC",
                            "NOC1","NOC2","NOC",
                            "MBC_R","Enz.deg")
      Cpools[, "Hour"] <- LFLT_stage123$time
      Cpools[, "Temp"] <- LFLT_stage123$temp
    }
    #initial
    {
      Cpools[1,'MBC'] <- M0
      Cpools[1,'MBC1'] <- M0 * (1-dormancy.ratio)
      Cpools[1,'MBC2'] <- M0 * dormancy.ratio
      Cpools[1,'Enz'] <- Enz0
      Cpools[1,'Enz1'] <- Enz0 * (1-inactive.ratio)
      Cpools[1,'Enz2'] <- Enz0 * inactive.ratio
      Cpools[1,'P.DOC'] <- P.DOC.0 
      Cpools[1,'P.NOC'] <- P.NOC.0
      Cpools[1,'DOC1'] <- A.DOC.0 * (1-f1) 
      Cpools[1,'DOC2'] <- A.DOC.0 * f1 
      Cpools[1,'DOC'] <- A.DOC.0 + P.DOC.0  
      Cpools[1,'NOC1'] <- A.NOC.0 * (1-f2) 
      Cpools[1,'NOC2'] <- A.NOC.0 * f2
      Cpools[1,'NOC'] <- A.NOC.0 + P.NOC.0
      Cpools[1,'MBC_R'] <- 0
      Cpools[1,'Enz.deg'] <- 0
      
    }
    {
      DOC.uptake.K_vec <- T_correct.DOC.uptake.K(LFLT_stage123$temp,Slope_DOC.uptake.K,intercept_DOC.uptake.K)
      NOC.deg.K_vec <- T_correct.NOC.deg.K(LFLT_stage123$temp,Slope_NOC.deg.K,intercept_NOC.deg.K)
      CUE_vec <- T_correct.CUE(LFLT_stage123$temp,Slope_CUE,intercept_CUE)
      Csor1_vec <- T_correct.C.sor1(LFLT_stage123$temp,Slope_C.sor1,intercept_C.sor1)
      Csor2_vec <- T_correct.C.sor2(LFLT_stage123$temp,Slope_C.sor2,intercept_C.sor2)
      r1_vec <- T_correct.r1(LFLT_stage123$temp,Slope_r1,intercept_r1)
      r2_vec <- T_correct.r2(LFLT_stage123$temp,Slope_r2,intercept_r2)
      P.DOC.above0_vec <-  T_correct.above0.P.DOC(LFLT_stage123$temp,Slope_above0.P.DOC,intercept_P.DOC)
      P.NOC.above0_vec <-  T_correct.above0.P.NOC(LFLT_stage123$temp,Slope_above0.P.NOC,intercept_P.NOC)
      temp.cor_vec <- T_correct(LFLT_stage123$temp)     
      temp.cor.ice_vec <- T_correct.ice(LFLT_stage123$temp)     
      temp.cor.increase_vec <- T_correct_increase(LFLT_stage123$temp)
    }
    for (jj in 1:(timesteps-1)){ 
      #parameters prepare
      {
        temp <- LFLT_stage123$temp[jj] 
        DOC.uptake.K <- DOC.uptake.K_vec[jj]
        NOC.deg.K <- NOC.deg.K_vec[jj]
        CUE <- CUE_vec[jj]
        Csor1 <- Csor1_vec[jj]
        Csor2 <- Csor2_vec[jj]
        r1 <- r1_vec[jj]
        r2 <- r2_vec[jj]
        P.DOC.above0 <- P.DOC.above0_vec[jj]
        P.NOC.above0 <- P.NOC.above0_vec[jj]
        temp.cor <- temp.cor_vec[jj]
        temp.cor.ice <- temp.cor.ice_vec[jj]
        temp.cor.increase <- temp.cor.increase_vec[jj]
      }
      
      MBC1=Cpools[jj,'MBC1'] 
      MBC2=Cpools[jj,'MBC2'] 
      Enz1=Cpools[jj,'Enz1'] 
      Enz2=Cpools[jj,'Enz2'] 
      DOC1=Cpools[jj,'DOC1'] 
      DOC2=Cpools[jj,'DOC2'] 
      DOC=Cpools[jj,'DOC'] 
      NOC1=Cpools[jj,'NOC1'] 
      NOC2=Cpools[jj,'NOC2'] 
      NOC=Cpools[jj,'NOC'] 
      P.DOC=Cpools[jj,'P.DOC'] 
      P.NOC=Cpools[jj,'P.NOC'] 
      
      deltaC = Flux_all(
        V=V,temp=temp,
        DOC.uptake.K=DOC.uptake.K,
        DOC.uptake.Ea=DOC.uptake.Ea,
        Enz.P=Enz.P,
        Enz.D=Enz.D,
        MBC.D=MBC.D,
        MBC.D.ice=MBC.D.ice,
        NOC.deg.K=NOC.deg.K,
        NOC.deg.Ea=NOC.deg.Ea,
        gas=gas,
        Csor1=Csor1,Csor2=Csor2,
        r1=r1,r2=r2,
        CUE=CUE,f=f,f1=f1,f2=f2,
        P.DOC.above0,P.NOC.above0,
        MBC1=MBC1,MBC2=MBC2,
        Enz1=Enz1,Enz2=Enz2,
        DOC1=DOC1,DOC2=DOC2,
        NOC1=NOC1,NOC2=NOC2,
        P.DOC=P.DOC,P.NOC=P.NOC,
        temp.cor=temp.cor,
        temp.cor.ice=temp.cor.ice,
        temp.cor.increase=temp.cor.increase
      )		
      deltaC <- as.numeric(deltaC)
      
      Cpools[jj+1,3] = Cpools[jj,3] + deltaC[1] #MBC
      Cpools[jj+1,4] = Cpools[jj,4] + deltaC[2] #MBC1
      Cpools[jj+1,5] = Cpools[jj,5] + deltaC[3] #MBC2
      Cpools[jj+1,6] = Cpools[jj,6] + deltaC[4] #Enz
      Cpools[jj+1,7] = Cpools[jj,7] + deltaC[5] #Enz1
      Cpools[jj+1,8] = Cpools[jj,8] + deltaC[6] #Enz2
      Cpools[jj+1,9] = Cpools[jj,9] + deltaC[7] #P.DOC
      Cpools[jj+1,10] =  Cpools[jj,10] + deltaC[8] #P.NOC   
      Cpools[jj+1,11] =  Cpools[jj,11] + deltaC[9]  #DOC1
      Cpools[jj+1,12] =  Cpools[jj,12] + deltaC[10] #DOC2
      Cpools[jj+1,13] =  Cpools[jj,13] + deltaC[11] #DOC
      Cpools[jj+1,14] =  Cpools[jj,14] + deltaC[12] #NOC1
      Cpools[jj+1,15] =  Cpools[jj,15] + deltaC[13] #NOC2
      Cpools[jj+1,16] =  Cpools[jj,16] + deltaC[14] #NOC
      Cpools[jj+1,17] = deltaC[15] #MBC_R
      Cpools[jj+1,18] = deltaC[16] #Enz.deg
    }
    return(Cpools)
  }
}
###
### Physio model
###
{
  Flux_all <- function(
    V,temp,
    DOC.uptake.K,
    DOC.uptake.Ea,
    Enz.P,
    Enz.D,
    MBC.D,
    MBC.D.ice,
    NOC.deg.K,
    NOC.deg.Ea,
    gas,
    Csor1,Csor2,r1,r2,
    CUE,f,f1,f2,
    P.DOC.above0,
    P.NOC.above0,
    MBC1,MBC2,
    Enz1,Enz2,
    DOC1,DOC2,
    NOC1,NOC2,
    P.DOC,P.NOC,
    temp.cor,
    temp.cor.ice,
    temp.cor.increase
  ){
    ###
    ###MBC1
    ###
    {
      # Model above 0 °C
      # 1. Active at all temperatures, without physical isolation, involved in DOC uptake, mortality, and enzyme production.
      same1 = V[1] * DOC1 / (DOC.uptake.K+DOC1) * exp(-(DOC.uptake.Ea)/(gas*(temp+273)))
      same2 = V[1] * DOC2 / (DOC.uptake.K+DOC2) * exp(-(DOC.uptake.Ea)/(gas*(temp+273)))
      
      # 1. MBC1.1
      ### Microbial uptake of DOC
      MBC1_U.1 = MBC1 * same1   # MM function and Arrhenius equation
      
      ### Microbial mortality
      MBC1_D = MBC1 * MBC.D   
      
      ### Freeze-induced microbial mortality
      MBC1_D.ice = MBC1 * MBC.D.ice * temp.cor.ice
      
      ### Enzyme production
      Enz1_P = MBC1 * Enz.P   
      
      ### Microbial respiration
      MBC1_R.1 = MBC1_U.1 * (1 - CUE)  # Fraction allocated to respiration multiplied by DOC uptake by MBC
      
      ### Microbial growth
      MBC1_G.1 = MBC1_U.1 * CUE  # Fraction allocated to growth multiplied by DOC uptake by MBC
      
      # Model above 0 °C
      # 1. Active at all temperatures, with physical isolation, involved in DOC uptake, mortality, and enzyme production.
      ### Microbial uptake of DOC
      MBC1_U.2 = MBC1 * same2  * temp.cor    # MM function and Arrhenius equation
      
      ### Microbial respiration
      MBC1_R.2 = MBC1_U.2 * (1 - CUE)  # Fraction allocated to respiration multiplied by DOC uptake by MBC
      
      ### Microbial growth
      MBC1_G.2 = MBC1_U.2 * CUE  # Fraction allocated to growth multiplied by DOC uptake by MBC
      
      MBC1_R = MBC1_R.1 + MBC1_R.2
      MBC1_G = MBC1_G.1 + MBC1_G.2
    }
    
    ###
    ###MBC2
    ###
    {
      # 2. Dormant below 0 °C, without DOC uptake or enzyme production, only involved in mortality.
      # 2. MBC2
      
      ### Microbial uptake of DOC
      MBC2_U.1 = MBC2 * same1 * temp.cor   # MM function and Arrhenius equation
      
      ### Microbial mortality
      MBC2_D = MBC2 * MBC.D   * temp.cor
      
      ### Enzyme production
      Enz2_P = MBC2 * Enz.P   * temp.cor
      
      ### Microbial respiration
      MBC2_R.1 = MBC2_U.1 * (1 - CUE)  # Fraction allocated to respiration multiplied by DOC uptake by MBC
      
      ### Microbial growth
      MBC2_G.1 = MBC2_U.1 * CUE  # Fraction allocated to growth multiplied by DOC uptake by MBC
      
      # 2. Dormant below 0 °C, without DOC uptake or enzyme production, only involved in mortality.
      # 2. MBC2
      
      ### Microbial uptake of DOC
      MBC2_U.2 = MBC2 * same2 * temp.cor   # MM function and Arrhenius equation
      
      ### Microbial respiration
      MBC2_R.2 = MBC2_U.2 * (1 - CUE)  # Fraction allocated to respiration multiplied by DOC uptake by MBC
      
      ### Microbial growth
      MBC2_G.2 = MBC2_U.2 * CUE  # Fraction allocated to growth multiplied by DOC uptake by MBC
      
      MBC2_R = MBC2_R.1 + MBC2_R.2
      MBC2_G = MBC2_G.1 + MBC2_G.2
    }
    
    ###
    ### ENZ1
    ###
    {
      ### Enzymatic degradation of NOC into DOC
      # 1. Active at all temperatures, without physical isolation, involved in DOC production and decay.
      
      same3 = V[2] * NOC1/(NOC.deg.K + NOC1) * exp(-(NOC.deg.Ea[1])/(gas*(temp+273)))
      same4 = V[2] * NOC2/(NOC.deg.K + NOC2) * exp(-(NOC.deg.Ea[1])/(gas*(temp+273)))
      
      # 1. Enz to NOC1
      Enz1_deg.1 = Enz1 * same3     # MM function and Arrhenius equation
      
      # 2. Active at all temperatures, with physical isolation, involved in DOC production and decay.
      # 2. Enz to NOC2
      Enz1_deg.2 = Enz1 *same4 * temp.cor     # MM function and Arrhenius equation
      
      ###
      Enz1_deg = Enz1_deg.1 + Enz1_deg.2
      
      ### Enzyme decay
      Enz1_D = Enz1 * Enz.D  
    }
    
    ###
    ### ENZ2
    ###
    {
      ### Enzymatic degradation of NOC into DOC
      # 1. Inactive below 0 °C, without physical isolation, involved in DOC production and decay.
      
      # 1. Enz to NOC1
      Enz2_deg.1 = Enz2 * same3 * temp.cor     # MM function and Arrhenius equation
      
      # 2. Enz to NOC2
      Enz2_deg.2 = Enz2 * same4 * temp.cor     # MM function and Arrhenius equation
      
      ###
      Enz2_deg = Enz2_deg.1 + Enz2_deg.2
      
      ### Enzyme decay
      Enz2_D = Enz2 * Enz.D  
      
      Enz_deg = Enz1_deg + Enz2_deg
      Enz_D = Enz1_D + Enz2_D
    }
    
    ### Sorption between available organic carbon and organic carbon
    {
      sorption.DOC1 =  Csor1 * DOC1
      sorption.DOC2 =  Csor1 * DOC2 * temp.cor # Physically isolated and unavailable for sorption
      sorption.A.DOC = sorption.DOC1 + sorption.DOC2
      
      sorption.NOC1 =  Csor2 * NOC1
      sorption.NOC2 =  Csor2 * NOC2 * temp.cor # Physically isolated and unavailable for sorption
      sorption.A.NOC = sorption.NOC1 + sorption.NOC2
      
      ### Desorption between protected organic carbon and available organic carbon
      ### Transfer from P.DOC to A.DOC
      ### Transfer from P.NOC to A.NOC
      ### Desorption rate
      desorption.P.DOC = r1 * P.DOC
      desorption.P.NOC = r2 * P.NOC
    }
    
    ### Changes in carbon pools at different time points
    
    ### Changes in microbial carbon pools
    dMBC1 =  MBC1_G -            # Input - DOC used by microbes
      (MBC1_D + MBC1_D.ice + Enz1_P)    # Output - dead microbes plus microbial biomass allocated to enzymes
    
    dMBC2 = MBC2_G -            # Input - DOC used by microbes
      (MBC2_D + Enz2_P)    # Output - dead microbes plus microbial biomass allocated to enzymes
    
    dMBC = dMBC1 + dMBC2
    
    ### Changes in enzyme pools
    dEnz = Enz1_P + Enz2_P - Enz_D
    dEnz1 = Enz1_P - Enz1_D
    dEnz2 = Enz2_P - Enz2_D
    
    # Release through aggregate breakdown
    Break.DOC = P.DOC * P.DOC.above0 * temp.cor.increase
    Break.NOC = P.NOC * P.NOC.above0 * temp.cor.increase
    
    ### Change in the protected DOC pool
    dP.DOC = sorption.A.DOC  -  # Input
      (Break.DOC + desorption.P.DOC)  # Output
    
    ### Change in the protected NOC pool
    dP.NOC = sorption.A.NOC -  # Input
      (Break.NOC + desorption.P.NOC)  # Output
    
    ### Change in the available DOC pool
    dDOC1 =   (MBC1_D + MBC2_D + MBC1_D.ice)*f*(1-f1) +            # Input
      (Enz_deg*(1-f1)) +                    # Input
      (Enz_D*(1-f1)) +                      # Input
      (Break.DOC + desorption.P.DOC)*(1-f1) - # Input
      (MBC1_U.1 + MBC2_U.1)-  # Output
      sorption.DOC1   # Output
    
    ### Change in the physically isolated available DOC pool
    dDOC2 =  (MBC1_D + MBC2_D + MBC1_D.ice)*f*f1 +        # Input
      Enz_deg*f1 +                 # Input
      Enz_D*f1 +                   # Input
      (Break.DOC + desorption.P.DOC)*f1 - # Input
      (MBC1_U.2 + MBC2_U.2)-      # Output
      sorption.DOC2         # Output
    
    dDOC = dDOC1 + dDOC2 + dP.DOC
    
    ### Change in the available NOC pool
    dNOC1 = (MBC1_D + MBC2_D + MBC1_D.ice)*(1-f)*(1-f2) +            # Input
      (Break.NOC + desorption.P.NOC)*(1-f2)  -  # Input
      (Enz_deg)*(1-f2) - sorption.NOC1           # Output
    
    ### Change in the physically isolated available NOC pool
    dNOC2 = (MBC1_D + MBC2_D + MBC1_D.ice)*(1-f)*f2 +            # Input
      (Break.NOC + desorption.P.NOC)*f2  -  # Input
      (Enz_deg)*f2 - sorption.NOC2                  # Output
    
    dNOC = dNOC1 + dNOC2 + dP.NOC
    
    ### Microbial respiration
    MBC_R = MBC1_R + MBC2_R
    
    ### Enzymatic degradation of SOC
    Enz.deg = Enz_deg
    
    # Output
    c(dMBC,    # Microbial biomass
      dMBC1,   # Microbial biomass, microbes active at all temperatures
      dMBC2,   # Microbial biomass, microbes active only above 0 °C
      dEnz,    # Daily change in total enzymes
      dEnz1,   #
      dEnz2,   #
      
      dP.DOC,
      dP.NOC,
      
      dDOC1,    # Daily change in DOC, constrained by measured values
      dDOC2,
      dDOC,
      
      dNOC1,    # Daily change in NOC
      dNOC2,    
      dNOC,
      
      MBC_R,    # Daily microbial respiration, constrained by measured values
      Enz.deg   # Enzymatic degradation of SOC, constrained by measured values
    )
    
  }
  #Prepare function
  {
    #Temp~time
    thaw_to_freeze <- function(x){10 - t * (x)}
    freeze_to_thaw <- function(x){-10 + t * (x)}
    # half-saturation constant of DOC
    T_correct.DOC.uptake.K <- function(temp,Slope_DOC.uptake.K,intercept_DOC.uptake.K) { Slope_DOC.uptake.K * temp + intercept_DOC.uptake.K  }
    # half-saturation constant of SOC
    T_correct.NOC.deg.K <- function(temp,Slope_NOC.deg.K,intercept_NOC.deg.K) { Slope_NOC.deg.K * temp + intercept_NOC.deg.K  }
    # CUE
    T_correct.CUE <- function(temp,Slope_CUE,intercept_CUE){ Slope_CUE * temp + intercept_CUE } 
    #breakdown coefficient of DOC
    T_correct.above0.P.DOC <- function(temp,Slope_above0.P.DOC,intercept_P.DOC){ Slope_above0.P.DOC * temp + intercept_P.DOC } 
    #breakdown coefficient of SOC
    T_correct.above0.P.NOC <- function(temp,Slope_above0.P.NOC,intercept_P.NOC){ Slope_above0.P.NOC * temp + intercept_P.NOC } 
    #sorption
    T_correct.C.sor1 <- function(temp,Slope_C.sor1,intercept_C.sor1){ Slope_C.sor1 * temp + intercept_C.sor1 } 
    T_correct.C.sor2 <- function(temp,Slope_C.sor2,intercept_C.sor2){ Slope_C.sor2 * temp + intercept_C.sor2 } 
    #desorption
    T_correct.r1 <- function(temp,Slope_r1,intercept_r1){ Slope_r1 * temp + intercept_r1 } 
    T_correct.r2 <- function(temp,Slope_r2,intercept_r2){ Slope_r2 * temp + intercept_r2 } 
    #dormancy
    T_correct <- function(temp){ifelse(temp < 0, 0, 1)}
    #For freeze death
    T_correct.ice <- function(temp){ifelse(temp < 0, 1, 0)}
    #For aggregate break release
    T_correct_increase <- function(temp) {
      dtemp <- c(0, diff(temp))
      mark <- ifelse(temp >= 0 & temp <= 10 & dtemp > 0, 1, 0)
      return(mark)
    }
  }
  
  Model.physio.T2 <- function(x,MB0,DOC0,CUE10) {
    #parameters prepare
    {
      ###
      T0 <-  1e+6			        # Total SOC unit: 10^6 micrograms == 1 g
      gas <- 8.314
      ### 
      M0	<- 	MB0		 # microbial biomass carbon (measured value)
      f.enz <- .02   # initial enzyme ratio #set to 2% ###same for the four cycles of the same soil###
      Enz0 <-  M0 * f.enz      # initial enzyme value (assumed to be half of microbial biomass carbon)
      C0 	<-	T0 - MB0 - Enz0	 # carbon excluding microbes and enzymes, i.e., DOC + SOC
      # ratio of protected DOC to available DOC
      f.A.DOC_P.DOC <- 0.5 # A.DOC #set to 40-60% ###same for the four cycles of the same soil###
      P.DOC.0 <- DOC0 * (1-f.A.DOC_P.DOC)  #protected DOC content
      A.DOC.0 <- DOC0 * f.A.DOC_P.DOC  #available DOC content
      # fraction of protected recalcitrant carbon
      f.P.NOC <- 0.5  ###same for the four cycles of the same soil###
      P.NOC.0 <- (C0 -  DOC0)*(f.P.NOC)   #protected recalcitrant carbon content
      A.NOC.0 <- (C0 -  DOC0)*(1-f.P.NOC) #available recalcitrant carbon content
      
      #higher temperature promotes desorption
      #lower temperature promotes sorption
      ### DOC sorption
      C.sor1.10 <- x[1] 
      C.sor1.minus10 <- x[2]
      intercept_C.sor1 <- (C.sor1.10 + C.sor1.minus10)/2 # sorption coefficient
      Slope_C.sor1 <- (C.sor1.10 - C.sor1.minus10)/20    # 
      ### SOC sorption
      C.sor2.10 <- x[3] 
      C.sor2.minus10 <- x[4]
      intercept_C.sor2 <- (C.sor2.10 + C.sor2.minus10)/2 # sorption coefficient
      Slope_C.sor2 <- (C.sor2.10 - C.sor2.minus10)/20    # 
      ### DOC desorption
      r1.10 <- x[5] 
      r1.minus10 <- x[6] 
      intercept_r1 <- (r1.10 + r1.minus10)/2 # desorption coefficient
      Slope_r1 <- (r1.10 - r1.minus10)/20    # desorption coefficient
      ### SOC desorption
      r2.10 <- x[7]
      r2.minus10 <- x[8] 
      intercept_r2 <- (r2.10 + r2.minus10)/2 # desorption coefficient
      Slope_r2 <- (r2.10 - r2.minus10)/20    # desorption coefficient
      
      ###
      V <- exp(x[9:10])  # maximum rate of microbial DOC uptake / maximum rate of enzyme NOC degradation
      DOC.uptake.Ea <- 47 # activation energy for microbial DOC uptake
      NOC.deg.Ea 	 <-	47 	# activation energy for enzyme NOC degradation
      f  <-	 .2           # fraction of dead microbial biomass converted to DOC
      
      #from -10 to 10 degrees, Km decreases as temperature rises and activity increases
      ###MBC uptake of DOC
      DOC.uptake.K.10 <- A.DOC.0*0.2 ###same for the four cycles of the same soil set to 45-55%###
      DOC.uptake.K.minus10 <- A.DOC.0*0.8 ###same for the four cycles of the same soil set to 55-60%###
      intercept_DOC.uptake.K <- (DOC.uptake.K.10+DOC.uptake.K.minus10)/2 # intercept of microbial DOC uptake half-saturation constant
      Slope_DOC.uptake.K <- (DOC.uptake.K.10-DOC.uptake.K.minus10)/20    # slope of microbial DOC uptake half-saturation constant
      ###Enz degradation of NOC
      NOC.deg.K.10 <- A.NOC.0*0.2 ###same for the four cycles of the same soil set to 45-55%###
      NOC.deg.K.minus10 <- A.NOC.0*0.8 ###same for the four cycles of the same soil set to 55-60%###
      intercept_NOC.deg.K <- (NOC.deg.K.10+NOC.deg.K.minus10)/2    # intercept of enzyme NOC degradation
      Slope_NOC.deg.K <- (NOC.deg.K.10-NOC.deg.K.minus10)/20       # slope of enzyme NOC degradation
      #enzyme death
      Enz.D <- exp(x[11])
      #microbial physiological mortality
      MBC.D <- exp(x[12])
      #microbial enzyme production
      Enz.P <- exp(x[13])
      #microbial CUE
      CUE.10 <- CUE10       #based on measured value ###same for the four cycles of the same soil###
      CUE.minus10 <- x[14]  
      intercept_CUE <- (CUE.10+CUE.minus10)/2
      Slope_CUE <- (CUE.10-CUE.minus10)/20
      #physical mechanism
      f1 <- 0   # below 0 degrees, A.DOC isolation coefficient set to 40-60%  
      f2 <- f1   # below 0 degrees, A.SOC isolation coefficient set to 40-60%  
      #intercept of protected DOC breakdown coefficient
      intercept_P.DOC <- 0
      #calculate slope from intercept
      Slope_above0.P.DOC <- -(intercept_P.DOC/10)
      #intercept of protected NOC breakdown coefficient
      intercept_P.NOC <- 0
      #calculate slope from intercept
      Slope_above0.P.NOC <- -(intercept_P.NOC/10)
      
      #physiological mechanism
      dormancy.ratio <- x[15]  # microbial dormancy ratio
      inactive.ratio <- x[16]  # enzyme inactive ratio
      # microbial freeze-death ratio due to water freezing
      MBC.D.ice <- exp(x[17])
      
    } 
    {     
      timesteps <- length(LFLT_stage123$temp)
      Cpools <- matrix(0, nrow = timesteps, ncol = 18)
      colnames(Cpools) <- c("Hour","Temp",
                            "MBC","MBC1","MBC2",
                            "Enz","Enz1","Enz2",
                            "P.DOC","P.NOC",
                            "DOC1","DOC2","DOC",
                            "NOC1","NOC2","NOC",
                            "MBC_R","Enz.deg")
      Cpools[, "Hour"] <- LFLT_stage123$time
      Cpools[, "Temp"] <- LFLT_stage123$temp
    }
    #initial values
    {
      Cpools[1,'MBC'] <- M0
      Cpools[1,'MBC1'] <- M0 * (1-dormancy.ratio)
      Cpools[1,'MBC2'] <- M0 * dormancy.ratio
      Cpools[1,'Enz'] <- Enz0
      Cpools[1,'Enz1'] <- Enz0 * (1-inactive.ratio)
      Cpools[1,'Enz2'] <- Enz0 * inactive.ratio
      Cpools[1,'P.DOC'] <- P.DOC.0 
      Cpools[1,'P.NOC'] <- P.NOC.0
      Cpools[1,'DOC1'] <- A.DOC.0 * (1-f1) 
      Cpools[1,'DOC2'] <- A.DOC.0 * f1 
      Cpools[1,'DOC'] <- A.DOC.0 + P.DOC.0  
      Cpools[1,'NOC1'] <- A.NOC.0 * (1-f2) 
      Cpools[1,'NOC2'] <- A.NOC.0 * f2
      Cpools[1,'NOC'] <- A.NOC.0 + P.NOC.0
      Cpools[1,'MBC_R'] <- 0
      Cpools[1,'Enz.deg'] <- 0
      
    }
    {
      DOC.uptake.K_vec <- T_correct.DOC.uptake.K(LFLT_stage123$temp,Slope_DOC.uptake.K,intercept_DOC.uptake.K)
      NOC.deg.K_vec <- T_correct.NOC.deg.K(LFLT_stage123$temp,Slope_NOC.deg.K,intercept_NOC.deg.K)
      CUE_vec <- T_correct.CUE(LFLT_stage123$temp,Slope_CUE,intercept_CUE)
      Csor1_vec <- T_correct.C.sor1(LFLT_stage123$temp,Slope_C.sor1,intercept_C.sor1)
      Csor2_vec <- T_correct.C.sor2(LFLT_stage123$temp,Slope_C.sor2,intercept_C.sor2)
      r1_vec <- T_correct.r1(LFLT_stage123$temp,Slope_r1,intercept_r1)
      r2_vec <- T_correct.r2(LFLT_stage123$temp,Slope_r2,intercept_r2)
      P.DOC.above0_vec <-  T_correct.above0.P.DOC(LFLT_stage123$temp,Slope_above0.P.DOC,intercept_P.DOC)
      P.NOC.above0_vec <-  T_correct.above0.P.NOC(LFLT_stage123$temp,Slope_above0.P.NOC,intercept_P.NOC)
      temp.cor_vec <- T_correct(LFLT_stage123$temp)     
      temp.cor.ice_vec <- T_correct.ice(LFLT_stage123$temp)     
      temp.cor.increase_vec <- T_correct_increase(LFLT_stage123$temp)
    }
    for (jj in 1:(timesteps-1)){ 
      
      {
        temp <- LFLT_stage123$temp[jj] #start from the second row
        #microbial DOC uptake half-saturation constant (temperature-dependent)
        DOC.uptake.K <- DOC.uptake.K_vec[jj]
        #enzyme NOC degradation half-saturation constant (temperature-dependent)
        NOC.deg.K <- NOC.deg.K_vec[jj]
        #microbial CUE (temperature-dependent)
        CUE <- CUE_vec[jj]
        #DOC and SOC sorption
        Csor1 <- Csor1_vec[jj]
        Csor2 <- Csor2_vec[jj]
        #P.DOC and P.SOC desorption
        r1 <- r1_vec[jj]
        r2 <- r2_vec[jj]
        #protected DOC breakdown coefficient
        P.DOC.above0 <- P.DOC.above0_vec[jj]
        #protected NOC breakdown coefficient
        P.NOC.above0 <- P.NOC.above0_vec[jj]
        #for dormant microbes, inactive enzymes, and physical isolation; set to 0 below 0 degrees
        temp.cor <- temp.cor_vec[jj]
        #for microbes killed by freezing; set to 1 below 0 degrees and 0 above 0 degrees
        temp.cor.ice <- temp.cor.ice_vec[jj]
        #aggregate breakdown during thawing
        temp.cor.increase <- temp.cor.increase_vec[jj]
      }
     
      MBC1=Cpools[jj,'MBC1'] 
      MBC2=Cpools[jj,'MBC2'] 
      Enz1=Cpools[jj,'Enz1'] 
      Enz2=Cpools[jj,'Enz2'] 
      DOC1=Cpools[jj,'DOC1'] 
      DOC2=Cpools[jj,'DOC2'] 
      DOC=Cpools[jj,'DOC'] 
      NOC1=Cpools[jj,'NOC1'] 
      NOC2=Cpools[jj,'NOC2'] 
      NOC=Cpools[jj,'NOC'] 
      P.DOC=Cpools[jj,'P.DOC'] 
      P.NOC=Cpools[jj,'P.NOC'] 
      
      deltaC = Flux_all(
        V=V,temp=temp,
        DOC.uptake.K=DOC.uptake.K,
        DOC.uptake.Ea=DOC.uptake.Ea,
        Enz.P=Enz.P,
        Enz.D=Enz.D,
        MBC.D=MBC.D,
        MBC.D.ice=MBC.D.ice,
        NOC.deg.K=NOC.deg.K,
        NOC.deg.Ea=NOC.deg.Ea,
        gas=gas,
        Csor1=Csor1,Csor2=Csor2,
        r1=r1,r2=r2,
        CUE=CUE,f=f,f1=f1,f2=f2,
        P.DOC.above0,P.NOC.above0,
        MBC1=MBC1,MBC2=MBC2,
        Enz1=Enz1,Enz2=Enz2,
        DOC1=DOC1,DOC2=DOC2,
        NOC1=NOC1,NOC2=NOC2,
        P.DOC=P.DOC,P.NOC=P.NOC,
        temp.cor=temp.cor,
        temp.cor.ice=temp.cor.ice,
        temp.cor.increase=temp.cor.increase
      )		
      deltaC <- as.numeric(deltaC)
      
      Cpools[jj+1,3] = Cpools[jj,3] + deltaC[1] #MBC
      Cpools[jj+1,4] = Cpools[jj,4] + deltaC[2] #MBC1
      Cpools[jj+1,5] = Cpools[jj,5] + deltaC[3] #MBC2
      Cpools[jj+1,6] = Cpools[jj,6] + deltaC[4] #Enz
      Cpools[jj+1,7] = Cpools[jj,7] + deltaC[5] #Enz1
      Cpools[jj+1,8] = Cpools[jj,8] + deltaC[6] #Enz2
      Cpools[jj+1,9] = Cpools[jj,9] + deltaC[7] #P.DOC
      Cpools[jj+1,10] =  Cpools[jj,10] + deltaC[8] #P.NOC   
      Cpools[jj+1,11] =  Cpools[jj,11] + deltaC[9]  #DOC1
      Cpools[jj+1,12] =  Cpools[jj,12] + deltaC[10] #DOC2
      Cpools[jj+1,13] =  Cpools[jj,13] + deltaC[11] #DOC
      Cpools[jj+1,14] =  Cpools[jj,14] + deltaC[12] #NOC1
      Cpools[jj+1,15] =  Cpools[jj,15] + deltaC[13] #NOC2
      Cpools[jj+1,16] =  Cpools[jj,16] + deltaC[14] #NOC
      Cpools[jj+1,17] = deltaC[15] #MBC_R
      Cpools[jj+1,18] = deltaC[16] #Enz.deg
    }
    return(Cpools)
  }

  
}
###
### Physic model
###
{
  Flux_all <- function(
    V,temp,
    DOC.uptake.K,
    DOC.uptake.Ea,
    Enz.P,
    Enz.D,
    MBC.D,
    MBC.D.ice,
    NOC.deg.K,
    NOC.deg.Ea,
    gas,
    Csor1,Csor2,r1,r2,
    CUE,f,f1,f2,
    P.DOC.above0,
    P.NOC.above0,
    MBC1,MBC2,
    Enz1,Enz2,
    DOC1,DOC2,
    NOC1,NOC2,
    P.DOC,P.NOC,
    temp.cor,
    temp.cor.ice,
    temp.cor.increase
  ){
    ###
    ###MBC1
    ###
    {
      # model above 0 degrees
      #1. active at all temperatures, without physical isolation, involved in DOC uptake, mortality, and enzyme production.
      same1 = V[1] * DOC1 / (DOC.uptake.K+DOC1) * exp(-(DOC.uptake.Ea)/(gas*(temp+273)))
      same2 = V[1] * DOC2 / (DOC.uptake.K+DOC2) * exp(-(DOC.uptake.Ea)/(gas*(temp+273)))
      #1. MBC1.1
      ### microbial uptake of DOC
      MBC1_U.1 = MBC1 * same1   # MM function and  Arrhenius equation
      ### microbial mortality
      MBC1_D = MBC1 * MBC.D   
      ### microbial freeze mortality
      MBC1_D.ice = MBC1 * MBC.D.ice * temp.cor.ice
      ### enzyme production
      Enz1_P = MBC1 * Enz.P   
      ### microbial respiration
      MBC1_R.1 = MBC1_U.1 * (1 - CUE)  #respiration fraction multiplied by DOC taken up by MBC
      ### microbial growth
      MBC1_G.1 = MBC1_U.1 * CUE  #respiration fraction multiplied by DOC taken up by MBC
      
      # model above 0 degrees
      #1. active at all temperatures, with physical isolation, involved in DOC uptake, mortality, and enzyme production.
      ### microbial uptake of DOC
      MBC1_U.2 = MBC1 * same2  * temp.cor    # MM function and  Arrhenius equation
      ### microbial respiration
      MBC1_R.2 = MBC1_U.2 * (1 - CUE)  #respiration fraction multiplied by DOC taken up by MBC
      ### microbial growth
      MBC1_G.2 = MBC1_U.2 * CUE  #respiration fraction multiplied by DOC taken up by MBC
      
      MBC1_R = MBC1_R.1 + MBC1_R.2
      MBC1_G = MBC1_G.1 + MBC1_G.2
    }
    ###
    ###MBC2
    ###
    {
      #2. dormant below 0 degrees C; does not take up DOC or produce enzymes, only mortality occurs
      #2. MBC2
      ### microbial uptake of DOC
      MBC2_U.1 = MBC2 * same1 * temp.cor   # MM function and  Arrhenius equation
      ### microbial mortality
      MBC2_D = MBC2 * MBC.D   * temp.cor
      ### enzyme production
      Enz2_P = MBC2 * Enz.P   * temp.cor
      ### microbial respiration
      MBC2_R.1 = MBC2_U.1 * (1 - CUE)  #respiration fraction multiplied by DOC taken up by MBC
      ### microbial growth
      MBC2_G.1 = MBC2_U.1 * CUE  #respiration fraction multiplied by DOC taken up by MBC
      
      #2. dormant below 0 degrees C; does not take up DOC or produce enzymes, only mortality occurs
      #2. MBC2
      ### microbial uptake of DOC
      MBC2_U.2 = MBC2 * same2 * temp.cor   # MM function and  Arrhenius equation
      ### microbial respiration
      MBC2_R.2 = MBC2_U.2 * (1 - CUE)  #respiration fraction multiplied by DOC taken up by MBC
      ### microbial growth
      MBC2_G.2 = MBC2_U.2 * CUE  #respiration fraction multiplied by DOC taken up by MBC
      
      MBC2_R = MBC2_R.1 + MBC2_R.2
      MBC2_G = MBC2_G.1 + MBC2_G.2
    }
    ###
    ### ENZ1
    ###
    {
      ### enzyme degradation of NOC to DOC
      #1. active at all temperatures, without physical isolation, involved in DOC production and death
      
      same3 = V[2] * NOC1/(NOC.deg.K + NOC1) * exp(-(NOC.deg.Ea[1])/(gas*(temp+273)))
      same4 = V[2] * NOC2/(NOC.deg.K + NOC2) * exp(-(NOC.deg.Ea[1])/(gas*(temp+273)))
      
      #1. Enz~NOC1
      Enz1_deg.1 = Enz1 * same3     # MM function and  Arrhenius equation
      #2. active at all temperatures, with physical isolation, involved in DOC production and death
      #2. Enz~NOC2
      Enz1_deg.2 = Enz1 *same4 * temp.cor     # MM function and  Arrhenius equation
      ###
      Enz1_deg = Enz1_deg.1 + Enz1_deg.2
      ### enzyme death
      Enz1_D = Enz1 * Enz.D  
    }
    ###
    ### ENZ2
    ###
    {
      ### enzyme degradation of NOC to DOC
      #1. inactive below 0 degrees, without physical isolation, involved in DOC production and death
      #1. Enz~NOC1
      Enz2_deg.1 = Enz2 * same3 * temp.cor     # MM function and  Arrhenius equation
      #2. Enz~NOC2
      Enz2_deg.2 = Enz2 * same4 * temp.cor     # MM function and  Arrhenius equation
      ###
      Enz2_deg = Enz2_deg.1 + Enz2_deg.2
      ### enzyme death
      Enz2_D = Enz2 * Enz.D  
      
      Enz_deg = Enz1_deg + Enz2_deg
      Enz_D = Enz1_D + Enz2_D
    }
    ### sorption between available organic carbon and organic carbon 
    {
      sorption.DOC1 =  Csor1 * DOC1
      sorption.DOC2 =  Csor1 * DOC2 * temp.cor #physically isolated, cannot undergo sorption
      sorption.A.DOC = sorption.DOC1 + sorption.DOC2
      
      sorption.NOC1 =  Csor2 * NOC1
      sorption.NOC2 =  Csor2 * NOC2 * temp.cor #physically isolated, cannot undergo sorption
      sorption.A.NOC = sorption.NOC1 + sorption.NOC2
      
      ### desorption from protected organic carbon to organic carbon 
      ### P.DOC to A.DOC
      ### P.NOC to A.NOC
      ### desorption rate
      desorption.P.DOC = r1 * P.DOC
      desorption.P.NOC = r2 * P.NOC
    }
    ### changes in carbon pools over time
    ### change in microbial carbon pools
    dMBC1 =  MBC1_G -            #input: DOC used by microbes      
      (MBC1_D + MBC1_D.ice + Enz1_P)    #output: dead microbes + microbes converted to enzymes
    
    dMBC2 = MBC2_G -            #input: DOC used by microbes      
      (MBC2_D + Enz2_P)    #output: dead microbes + microbes converted to enzymes
    
    dMBC = dMBC1 + dMBC2
    
    ### change in enzyme pools
    dEnz = Enz1_P + Enz2_P - Enz_D
    dEnz1 = Enz1_P - Enz1_D
    dEnz2 = Enz2_P - Enz2_D
    
    #aggregate breakdown release
    Break.DOC = P.DOC * P.DOC.above0 * temp.cor.increase
    Break.NOC = P.NOC * P.NOC.above0 * temp.cor.increase
    
    ### change in protected DOC carbon pool
    dP.DOC = sorption.A.DOC  -  #input
      (Break.DOC + desorption.P.DOC)  #output
    
    ### change in protected NOC carbon pool
    dP.NOC = sorption.A.NOC -  #input
      (Break.NOC + desorption.P.NOC)  #output
    
    ### change in available DOC carbon pool
    dDOC1 =   (MBC1_D + MBC2_D + MBC1_D.ice)*f*(1-f1) +            #input
      (Enz_deg*(1-f1)) +                    #input
      (Enz_D*(1-f1)) +                      #input
      (Break.DOC + desorption.P.DOC)*(1-f1) - #input
      (MBC1_U.1 + MBC2_U.1)-  #output
      sorption.DOC1   #output
    
    ### change in physically isolated available DOC carbon pool
    dDOC2 =  (MBC1_D + MBC2_D + MBC1_D.ice)*f*f1 +        #input
      Enz_deg*f1 +                 #input
      Enz_D*f1 +                   #input
      (Break.DOC + desorption.P.DOC)*f1 - #input
      (MBC1_U.2 + MBC2_U.2)-      #output
      sorption.DOC2         #output
    
    dDOC = dDOC1 + dDOC2 + dP.DOC
    
    ### change in available NOC carbon pool  
    dNOC1 = (MBC1_D + MBC2_D + MBC1_D.ice)*(1-f)*(1-f2) +            #input
      (Break.NOC + desorption.P.NOC)*(1-f2)  -  #input
      (Enz_deg)*(1-f2) - sorption.NOC1           #output
    
    ### change in physically isolated available NOC carbon pool  
    dNOC2 = (MBC1_D + MBC2_D + MBC1_D.ice)*(1-f)*f2 +            #input
      (Break.NOC + desorption.P.NOC)*f2  -  #input
      (Enz_deg)*f2 - sorption.NOC2                  #output
    
    dNOC = dNOC1 + dNOC2 + dP.NOC
    
    ### microbial respiration
    MBC_R = MBC1_R + MBC2_R
    
    ### enzyme degradation of SOC
    Enz.deg = Enz_deg
    
    #output
    c(dMBC,    #microbial biomass  
      dMBC1,   #microbial biomass    microbes active at all temperatures
      dMBC2,   #microbial biomass    microbes active only above 0 degrees
      dEnz,    #daily change in total enzyme
      dEnz1,    #
      dEnz2,    #
      
      dP.DOC,
      dP.NOC,
      
      dDOC1,    #daily DOC change    #(constrained by measured values)
      dDOC2,
      dDOC,
      
      dNOC1,    #daily NOC change
      dNOC2,    
      dNOC,
      
      MBC_R,    #daily microbial respiration #(constrained by measured values)
      Enz.deg  #enzyme degradation of SOC  #(constrained by measured values)
    )
    
  }
  #prepare temperature-related coefficients
  {
    #Temp~time
    thaw_to_freeze <- function(x){10 - t * (x)}
    freeze_to_thaw <- function(x){-10 + t * (x)}
    # half-saturation constant of DOC
    T_correct.DOC.uptake.K <- function(temp,Slope_DOC.uptake.K,intercept_DOC.uptake.K) { Slope_DOC.uptake.K * temp + intercept_DOC.uptake.K  }
    # half-saturation constant of SOC
    T_correct.NOC.deg.K <- function(temp,Slope_NOC.deg.K,intercept_NOC.deg.K) { Slope_NOC.deg.K * temp + intercept_NOC.deg.K  }
    # CUE
    T_correct.CUE <- function(temp,Slope_CUE,intercept_CUE){ Slope_CUE * temp + intercept_CUE } 
    #breakdown coefficient of DOC
    T_correct.above0.P.DOC <- function(temp,Slope_above0.P.DOC,intercept_P.DOC){ Slope_above0.P.DOC * temp + intercept_P.DOC } 
    #breakdown coefficient of SOC
    T_correct.above0.P.NOC <- function(temp,Slope_above0.P.NOC,intercept_P.NOC){ Slope_above0.P.NOC * temp + intercept_P.NOC } 
    #sorption
    T_correct.C.sor1 <- function(temp,Slope_C.sor1,intercept_C.sor1){ Slope_C.sor1 * temp + intercept_C.sor1 } 
    T_correct.C.sor2 <- function(temp,Slope_C.sor2,intercept_C.sor2){ Slope_C.sor2 * temp + intercept_C.sor2 } 
    #desorption
    T_correct.r1 <- function(temp,Slope_r1,intercept_r1){ Slope_r1 * temp + intercept_r1 } 
    T_correct.r2 <- function(temp,Slope_r2,intercept_r2){ Slope_r2 * temp + intercept_r2 } 
    #dormancy
    T_correct <- function(temp){ifelse(temp < 0, 0, 1)}
    #For freeze death
    T_correct.ice <- function(temp){ifelse(temp < 0, 1, 0)}
    #For aggregate break release
    T_correct_increase <- function(temp) {
      dtemp <- c(0, diff(temp))
      mark <- ifelse(temp >= 0 & temp <= 10 & dtemp > 0, 1, 0)
      return(mark)
    }
  }
  
  Model.physic.T2 <- function(x,MB0,DOC0,CUE10) {
    #parameter inputs
    {
      ###
      T0 <-  1e+6			        # Total SOC unit: 10^6 micrograms == 1 g
      gas <- 8.314
      
      
      ### 
      M0	<- 	MB0		 # microbial biomass carbon (measured value)
      f.enz <- .02   # initial enzyme ratio #set to 2% ###same for the four cycles of the same soil###
      Enz0 <-  M0 * f.enz      # initial enzyme value (assumed to be half of microbial biomass carbon)
      C0 	<-	T0 - MB0 - Enz0	 # carbon excluding microbes and enzymes, i.e., DOC + SOC
      # ratio of protected DOC to available DOC
      f.A.DOC_P.DOC <- 0.5 # A.DOC #set to 40-60% ###same for the four cycles of the same soil###
      P.DOC.0 <- DOC0 * (1-f.A.DOC_P.DOC)  #protected DOC content
      A.DOC.0 <- DOC0 * f.A.DOC_P.DOC  #available DOC content
      # fraction of protected recalcitrant carbon
      f.P.NOC <- 0.5  ###same for the four cycles of the same soil###
      P.NOC.0 <- (C0 -  DOC0)*(f.P.NOC)   #protected recalcitrant carbon content
      A.NOC.0 <- (C0 -  DOC0)*(1-f.P.NOC) #available recalcitrant carbon content
      
      #higher temperature promotes desorption
      #lower temperature promotes sorption
      ### DOC sorption
      C.sor1.10 <- x[1] 
      C.sor1.minus10 <- x[2]
      intercept_C.sor1 <- (C.sor1.10 + C.sor1.minus10)/2 # sorption coefficient
      Slope_C.sor1 <- (C.sor1.10 - C.sor1.minus10)/20    # 
      ### SOC sorption
      C.sor2.10 <- x[3] 
      C.sor2.minus10 <- x[4]
      intercept_C.sor2 <- (C.sor2.10 + C.sor2.minus10)/2 # sorption coefficient
      Slope_C.sor2 <- (C.sor2.10 - C.sor2.minus10)/20    # 
      ### DOC desorption
      r1.10 <- x[5] 
      r1.minus10 <- x[6] 
      intercept_r1 <- (r1.10 + r1.minus10)/2 # desorption coefficient
      Slope_r1 <- (r1.10 - r1.minus10)/20    # desorption coefficient
      ### SOC desorption
      r2.10 <- x[7]
      r2.minus10 <- x[8] 
      intercept_r2 <- (r2.10 + r2.minus10)/2 # desorption coefficient
      Slope_r2 <- (r2.10 - r2.minus10)/20    # desorption coefficient
      
      ###
      V <- exp(x[9:10])  # maximum rate of microbial DOC uptake / maximum rate of enzyme NOC degradation
      DOC.uptake.Ea <- 47 # activation energy for microbial DOC uptake
      NOC.deg.Ea 	 <-	47 	# activation energy for enzyme NOC degradation
      f  <-	 .2           # fraction of dead microbial biomass converted to DOC
      
      #from -10 to 10 degrees, Km decreases as temperature rises and activity increases
      ###MBC uptake of DOC
      DOC.uptake.K.10 <- A.DOC.0*0.2 ###same for the four cycles of the same soil set to 45-55%###
      DOC.uptake.K.minus10 <- A.DOC.0*0.8 ###same for the four cycles of the same soil set to 55-60%###
      intercept_DOC.uptake.K <- (DOC.uptake.K.10+DOC.uptake.K.minus10)/2 # intercept of microbial DOC uptake half-saturation constant
      Slope_DOC.uptake.K <- (DOC.uptake.K.10-DOC.uptake.K.minus10)/20    # slope of microbial DOC uptake half-saturation constant
      ###Enz degradation of NOC
      NOC.deg.K.10 <- A.NOC.0*0.2 ###same for the four cycles of the same soil set to 45-55%###
      NOC.deg.K.minus10 <- A.NOC.0*0.8 ###same for the four cycles of the same soil set to 55-60%###
      intercept_NOC.deg.K <- (NOC.deg.K.10+NOC.deg.K.minus10)/2    # intercept of enzyme NOC degradation
      Slope_NOC.deg.K <- (NOC.deg.K.10-NOC.deg.K.minus10)/20       # slope of enzyme NOC degradation
      #enzyme death
      Enz.D <- exp(x[11])
      #microbial physiological mortality
      MBC.D <- exp(x[12])
      #microbial enzyme production
      Enz.P <- exp(x[13])
      #microbial CUE
      CUE.10 <- CUE10       #based on measured value ###same for the four cycles of the same soil###
      CUE.minus10 <- x[14]  
      intercept_CUE <- (CUE.10+CUE.minus10)/2
      Slope_CUE <- (CUE.10-CUE.minus10)/20
      
      #physical mechanism
      f1 <- x[15]   # below 0 degrees, A.DOC isolation coefficient set to 40-60%  
      f2 <- f1   # below 0 degrees, A.SOC isolation coefficient set to 40-60%  
      #intercept of protected DOC breakdown coefficient
      intercept_P.DOC <- exp(x[16])
      #calculate slope from intercept
      Slope_above0.P.DOC <- -(intercept_P.DOC/10)
      #intercept of protected NOC breakdown coefficient
      intercept_P.NOC <- exp(x[17])
      #calculate slope from intercept
      Slope_above0.P.NOC <- -(intercept_P.NOC/10)
      
      #physiological mechanism
      dormancy.ratio <- 0  # microbial dormancy ratio
      inactive.ratio <- 0  # enzyme inactive ratio
      # microbial freeze-death ratio due to water freezing
      MBC.D.ice <- 0
      
    } 
    #data frame for all data
    {     
      timesteps <- length(LFLT_stage123$temp)
      Cpools <- matrix(0, nrow = timesteps, ncol = 18)
      colnames(Cpools) <- c("Hour","Temp",
                            "MBC","MBC1","MBC2",
                            "Enz","Enz1","Enz2",
                            "P.DOC","P.NOC",
                            "DOC1","DOC2","DOC",
                            "NOC1","NOC2","NOC",
                            "MBC_R","Enz.deg")
      Cpools[, "Hour"] <- LFLT_stage123$time
      Cpools[, "Temp"] <- LFLT_stage123$temp
    }
    #initial values
    {
      Cpools[1,'MBC'] <- M0
      Cpools[1,'MBC1'] <- M0 * (1-dormancy.ratio)
      Cpools[1,'MBC2'] <- M0 * dormancy.ratio
      Cpools[1,'Enz'] <- Enz0
      Cpools[1,'Enz1'] <- Enz0 * (1-inactive.ratio)
      Cpools[1,'Enz2'] <- Enz0 * inactive.ratio
      Cpools[1,'P.DOC'] <- P.DOC.0 
      Cpools[1,'P.NOC'] <- P.NOC.0
      Cpools[1,'DOC1'] <- A.DOC.0 * (1-f1) 
      Cpools[1,'DOC2'] <- A.DOC.0 * f1 
      Cpools[1,'DOC'] <- A.DOC.0 + P.DOC.0  
      Cpools[1,'NOC1'] <- A.NOC.0 * (1-f2) 
      Cpools[1,'NOC2'] <- A.NOC.0 * f2
      Cpools[1,'NOC'] <- A.NOC.0 + P.NOC.0
      Cpools[1,'MBC_R'] <- 0
      Cpools[1,'Enz.deg'] <- 0
      
    }
    #vectorize parameters to avoid repeated computation
    {
      DOC.uptake.K_vec <- T_correct.DOC.uptake.K(LFLT_stage123$temp,Slope_DOC.uptake.K,intercept_DOC.uptake.K)
      NOC.deg.K_vec <- T_correct.NOC.deg.K(LFLT_stage123$temp,Slope_NOC.deg.K,intercept_NOC.deg.K)
      CUE_vec <- T_correct.CUE(LFLT_stage123$temp,Slope_CUE,intercept_CUE)
      Csor1_vec <- T_correct.C.sor1(LFLT_stage123$temp,Slope_C.sor1,intercept_C.sor1)
      Csor2_vec <- T_correct.C.sor2(LFLT_stage123$temp,Slope_C.sor2,intercept_C.sor2)
      r1_vec <- T_correct.r1(LFLT_stage123$temp,Slope_r1,intercept_r1)
      r2_vec <- T_correct.r2(LFLT_stage123$temp,Slope_r2,intercept_r2)
      P.DOC.above0_vec <-  T_correct.above0.P.DOC(LFLT_stage123$temp,Slope_above0.P.DOC,intercept_P.DOC)
      P.NOC.above0_vec <-  T_correct.above0.P.NOC(LFLT_stage123$temp,Slope_above0.P.NOC,intercept_P.NOC)
      temp.cor_vec <- T_correct(LFLT_stage123$temp)     
      temp.cor.ice_vec <- T_correct.ice(LFLT_stage123$temp)     
      temp.cor.increase_vec <- T_correct_increase(LFLT_stage123$temp)
    }
    #process
    for (jj in 1:(timesteps-1)){ 
      #prepare temperature-related coefficients
      {
        temp <- LFLT_stage123$temp[jj] #start from the second row
        #microbial DOC uptake half-saturation constant (temperature-dependent)
        DOC.uptake.K <- DOC.uptake.K_vec[jj]
        #enzyme NOC degradation half-saturation constant (temperature-dependent)
        NOC.deg.K <- NOC.deg.K_vec[jj]
        #microbial CUE (temperature-dependent)
        CUE <- CUE_vec[jj]
        #DOC and SOC sorption
        Csor1 <- Csor1_vec[jj]
        Csor2 <- Csor2_vec[jj]
        #P.DOC and P.SOC desorption
        r1 <- r1_vec[jj]
        r2 <- r2_vec[jj]
        #protected DOC breakdown coefficient
        P.DOC.above0 <- P.DOC.above0_vec[jj]
        #protected NOC breakdown coefficient
        P.NOC.above0 <- P.NOC.above0_vec[jj]
        #for dormant microbes, inactive enzymes, and physical isolation; set to 0 below 0 degrees
        temp.cor <- temp.cor_vec[jj]
        #for microbes killed by freezing; set to 1 below 0 degrees and 0 above 0 degrees
        temp.cor.ice <- temp.cor.ice_vec[jj]
        #aggregate breakdown during thawing
        temp.cor.increase <- temp.cor.increase_vec[jj]
      }
      #iteration
      #substitute the defined parameters
      #accumulate change metrics
      MBC1=Cpools[jj,'MBC1'] 
      MBC2=Cpools[jj,'MBC2'] 
      Enz1=Cpools[jj,'Enz1'] 
      Enz2=Cpools[jj,'Enz2'] 
      DOC1=Cpools[jj,'DOC1'] 
      DOC2=Cpools[jj,'DOC2'] 
      DOC=Cpools[jj,'DOC'] 
      NOC1=Cpools[jj,'NOC1'] 
      NOC2=Cpools[jj,'NOC2'] 
      NOC=Cpools[jj,'NOC'] 
      P.DOC=Cpools[jj,'P.DOC'] 
      P.NOC=Cpools[jj,'P.NOC'] 
      
      deltaC = Flux_all(
        V=V,temp=temp,
        DOC.uptake.K=DOC.uptake.K,
        DOC.uptake.Ea=DOC.uptake.Ea,
        Enz.P=Enz.P,
        Enz.D=Enz.D,
        MBC.D=MBC.D,
        MBC.D.ice=MBC.D.ice,
        NOC.deg.K=NOC.deg.K,
        NOC.deg.Ea=NOC.deg.Ea,
        gas=gas,
        Csor1=Csor1,Csor2=Csor2,
        r1=r1,r2=r2,
        CUE=CUE,f=f,f1=f1,f2=f2,
        P.DOC.above0,P.NOC.above0,
        MBC1=MBC1,MBC2=MBC2,
        Enz1=Enz1,Enz2=Enz2,
        DOC1=DOC1,DOC2=DOC2,
        NOC1=NOC1,NOC2=NOC2,
        P.DOC=P.DOC,P.NOC=P.NOC,
        temp.cor=temp.cor,
        temp.cor.ice=temp.cor.ice,
        temp.cor.increase=temp.cor.increase
      )		
      deltaC <- as.numeric(deltaC)
      
      Cpools[jj+1,3] = Cpools[jj,3] + deltaC[1] #MBC
      Cpools[jj+1,4] = Cpools[jj,4] + deltaC[2] #MBC1
      Cpools[jj+1,5] = Cpools[jj,5] + deltaC[3] #MBC2
      Cpools[jj+1,6] = Cpools[jj,6] + deltaC[4] #Enz
      Cpools[jj+1,7] = Cpools[jj,7] + deltaC[5] #Enz1
      Cpools[jj+1,8] = Cpools[jj,8] + deltaC[6] #Enz2
      Cpools[jj+1,9] = Cpools[jj,9] + deltaC[7] #P.DOC
      Cpools[jj+1,10] =  Cpools[jj,10] + deltaC[8] #P.NOC   
      Cpools[jj+1,11] =  Cpools[jj,11] + deltaC[9]  #DOC1
      Cpools[jj+1,12] =  Cpools[jj,12] + deltaC[10] #DOC2
      Cpools[jj+1,13] =  Cpools[jj,13] + deltaC[11] #DOC
      Cpools[jj+1,14] =  Cpools[jj,14] + deltaC[12] #NOC1
      Cpools[jj+1,15] =  Cpools[jj,15] + deltaC[13] #NOC2
      Cpools[jj+1,16] =  Cpools[jj,16] + deltaC[14] #NOC
      Cpools[jj+1,17] = deltaC[15] #MBC_R
      Cpools[jj+1,18] = deltaC[16] #Enz.deg
    }
    return(Cpools)
  }

}
### 
### Base model
### 
{
  Flux_all <- function(
    V,temp,
    DOC.uptake.K,
    DOC.uptake.Ea,
    Enz.P,
    Enz.D,
    MBC.D,
    MBC.D.ice,
    NOC.deg.K,
    NOC.deg.Ea,
    gas,
    Csor1,Csor2,r1,r2,
    CUE,f,f1,f2,
    P.DOC.above0,
    P.NOC.above0,
    MBC1,MBC2,
    Enz1,Enz2,
    DOC1,DOC2,
    NOC1,NOC2,
    P.DOC,P.NOC,
    temp.cor,
    temp.cor.ice,
    temp.cor.increase
  ){
    ###
    ###MBC1
    ###
    {
      # model above 0 degrees
      #1. active at all temperatures, without physical isolation, involved in DOC uptake, mortality, and enzyme production.
      same1 = V[1] * DOC1 / (DOC.uptake.K+DOC1) * exp(-(DOC.uptake.Ea)/(gas*(temp+273)))
      same2 = V[1] * DOC2 / (DOC.uptake.K+DOC2) * exp(-(DOC.uptake.Ea)/(gas*(temp+273)))
      #1. MBC1.1
      ### microbial uptake of DOC
      MBC1_U.1 = MBC1 * same1   # MM function and  Arrhenius equation
      ### microbial mortality
      MBC1_D = MBC1 * MBC.D   
      ### microbial freeze mortality
      MBC1_D.ice = MBC1 * MBC.D.ice * temp.cor.ice
      ### enzyme production
      Enz1_P = MBC1 * Enz.P   
      ### microbial respiration
      MBC1_R.1 = MBC1_U.1 * (1 - CUE)  #respiration fraction multiplied by DOC taken up by MBC
      ### microbial growth
      MBC1_G.1 = MBC1_U.1 * CUE  #respiration fraction multiplied by DOC taken up by MBC
      
      # model above 0 degrees
      #1. active at all temperatures, with physical isolation, involved in DOC uptake, mortality, and enzyme production.
      ### microbial uptake of DOC
      MBC1_U.2 = MBC1 * same2  * temp.cor    # MM function and  Arrhenius equation
      ### microbial respiration
      MBC1_R.2 = MBC1_U.2 * (1 - CUE)  #respiration fraction multiplied by DOC taken up by MBC
      ### microbial growth
      MBC1_G.2 = MBC1_U.2 * CUE  #respiration fraction multiplied by DOC taken up by MBC
      
      MBC1_R = MBC1_R.1 + MBC1_R.2
      MBC1_G = MBC1_G.1 + MBC1_G.2
    }
    ###
    ###MBC2
    ###
    {
      #2. dormant below 0 degrees C; does not take up DOC or produce enzymes, only mortality occurs
      #2. MBC2
      ### microbial uptake of DOC
      MBC2_U.1 = MBC2 * same1 * temp.cor   # MM function and  Arrhenius equation
      ### microbial mortality
      MBC2_D = MBC2 * MBC.D   * temp.cor
      ### enzyme production
      Enz2_P = MBC2 * Enz.P   * temp.cor
      ### microbial respiration
      MBC2_R.1 = MBC2_U.1 * (1 - CUE)  #respiration fraction multiplied by DOC taken up by MBC
      ### microbial growth
      MBC2_G.1 = MBC2_U.1 * CUE  #respiration fraction multiplied by DOC taken up by MBC
      
      #2. dormant below 0 degrees C; does not take up DOC or produce enzymes, only mortality occurs
      #2. MBC2
      ### microbial uptake of DOC
      MBC2_U.2 = MBC2 * same2 * temp.cor   # MM function and  Arrhenius equation
      ### microbial respiration
      MBC2_R.2 = MBC2_U.2 * (1 - CUE)  #respiration fraction multiplied by DOC taken up by MBC
      ### microbial growth
      MBC2_G.2 = MBC2_U.2 * CUE  #respiration fraction multiplied by DOC taken up by MBC
      
      MBC2_R = MBC2_R.1 + MBC2_R.2
      MBC2_G = MBC2_G.1 + MBC2_G.2
    }
    ###
    ### ENZ1
    ###
    {
      ### enzyme degradation of NOC to DOC
      #1. active at all temperatures, without physical isolation, involved in DOC production and death
      
      same3 = V[2] * NOC1/(NOC.deg.K + NOC1) * exp(-(NOC.deg.Ea[1])/(gas*(temp+273)))
      same4 = V[2] * NOC2/(NOC.deg.K + NOC2) * exp(-(NOC.deg.Ea[1])/(gas*(temp+273)))
      
      #1. Enz~NOC1
      Enz1_deg.1 = Enz1 * same3     # MM function and  Arrhenius equation
      #2. active at all temperatures, with physical isolation, involved in DOC production and death
      #2. Enz~NOC2
      Enz1_deg.2 = Enz1 *same4 * temp.cor     # MM function and  Arrhenius equation
      ###
      Enz1_deg = Enz1_deg.1 + Enz1_deg.2
      ### enzyme death
      Enz1_D = Enz1 * Enz.D  
    }
    ###
    ### ENZ2
    ###
    {
      ### enzyme degradation of NOC to DOC
      #1. inactive below 0 degrees, without physical isolation, involved in DOC production and death
      #1. Enz~NOC1
      Enz2_deg.1 = Enz2 * same3 * temp.cor     # MM function and  Arrhenius equation
      #2. Enz~NOC2
      Enz2_deg.2 = Enz2 * same4 * temp.cor     # MM function and  Arrhenius equation
      ###
      Enz2_deg = Enz2_deg.1 + Enz2_deg.2
      ### enzyme death
      Enz2_D = Enz2 * Enz.D  
      
      Enz_deg = Enz1_deg + Enz2_deg
      Enz_D = Enz1_D + Enz2_D
    }
    ### sorption between available organic carbon and organic carbon 
    {
      sorption.DOC1 =  Csor1 * DOC1
      sorption.DOC2 =  Csor1 * DOC2 * temp.cor #physically isolated, cannot undergo sorption
      sorption.A.DOC = sorption.DOC1 + sorption.DOC2
      
      sorption.NOC1 =  Csor2 * NOC1
      sorption.NOC2 =  Csor2 * NOC2 * temp.cor #physically isolated, cannot undergo sorption
      sorption.A.NOC = sorption.NOC1 + sorption.NOC2
      
      ### desorption from protected organic carbon to organic carbon 
      ### P.DOC to A.DOC
      ### P.NOC to A.NOC
      ### desorption rate
      desorption.P.DOC = r1 * P.DOC
      desorption.P.NOC = r2 * P.NOC
    }
    ### changes in carbon pools over time
    ### change in microbial carbon pools
    dMBC1 =  MBC1_G -            #input: DOC used by microbes      
      (MBC1_D + MBC1_D.ice + Enz1_P)    #output: dead microbes + microbes converted to enzymes
    
    dMBC2 = MBC2_G -            #input: DOC used by microbes      
      (MBC2_D + Enz2_P)    #output: dead microbes + microbes converted to enzymes
    
    dMBC = dMBC1 + dMBC2
    
    ### change in enzyme pools
    dEnz = Enz1_P + Enz2_P - Enz_D
    dEnz1 = Enz1_P - Enz1_D
    dEnz2 = Enz2_P - Enz2_D
    
    #aggregate breakdown release
    Break.DOC = P.DOC * P.DOC.above0 * temp.cor.increase
    Break.NOC = P.NOC * P.NOC.above0 * temp.cor.increase
    
    ### change in protected DOC carbon pool
    dP.DOC = sorption.A.DOC  -  #input
      (Break.DOC + desorption.P.DOC)  #output
    
    ### change in protected NOC carbon pool
    dP.NOC = sorption.A.NOC -  #input
      (Break.NOC + desorption.P.NOC)  #output
    
    ### change in available DOC carbon pool
    dDOC1 =   (MBC1_D + MBC2_D + MBC1_D.ice)*f*(1-f1) +            #input
      (Enz_deg*(1-f1)) +                    #input
      (Enz_D*(1-f1)) +                      #input
      (Break.DOC + desorption.P.DOC)*(1-f1) - #input
      (MBC1_U.1 + MBC2_U.1)-  #output
      sorption.DOC1   #output
    
    ### change in physically isolated available DOC carbon pool
    dDOC2 =  (MBC1_D + MBC2_D + MBC1_D.ice)*f*f1 +        #input
      Enz_deg*f1 +                 #input
      Enz_D*f1 +                   #input
      (Break.DOC + desorption.P.DOC)*f1 - #input
      (MBC1_U.2 + MBC2_U.2)-      #output
      sorption.DOC2         #output
    
    dDOC = dDOC1 + dDOC2 + dP.DOC
    
    ### change in available NOC carbon pool  
    dNOC1 = (MBC1_D + MBC2_D + MBC1_D.ice)*(1-f)*(1-f2) +            #input
      (Break.NOC + desorption.P.NOC)*(1-f2)  -  #input
      (Enz_deg)*(1-f2) - sorption.NOC1           #output
    
    ### change in physically isolated available NOC carbon pool  
    dNOC2 = (MBC1_D + MBC2_D + MBC1_D.ice)*(1-f)*f2 +            #input
      (Break.NOC + desorption.P.NOC)*f2  -  #input
      (Enz_deg)*f2 - sorption.NOC2                  #output
    
    dNOC = dNOC1 + dNOC2 + dP.NOC
    
    ### microbial respiration
    MBC_R = MBC1_R + MBC2_R
    
    ### enzyme degradation of SOC
    Enz.deg = Enz_deg
    
    #output
    c(dMBC,    #microbial biomass  
      dMBC1,   #microbial biomass    microbes active at all temperatures
      dMBC2,   #microbial biomass    microbes active only above 0 degrees
      dEnz,    #daily change in total enzyme
      dEnz1,    #
      dEnz2,    #
      
      dP.DOC,
      dP.NOC,
      
      dDOC1,    #daily DOC change    #(constrained by measured values)
      dDOC2,
      dDOC,
      
      dNOC1,    #daily NOC change
      dNOC2,    
      dNOC,
      
      MBC_R,    #daily microbial respiration #(constrained by measured values)
      Enz.deg  #enzyme degradation of SOC  #(constrained by measured values)
    )
    
  }
  #prepare temperature-related coefficients
  {
    #Temp~time
    thaw_to_freeze <- function(x){10 - t * (x)}
    freeze_to_thaw <- function(x){-10 + t * (x)}
    # half-saturation constant of DOC
    T_correct.DOC.uptake.K <- function(temp,Slope_DOC.uptake.K,intercept_DOC.uptake.K) { Slope_DOC.uptake.K * temp + intercept_DOC.uptake.K  }
    # half-saturation constant of SOC
    T_correct.NOC.deg.K <- function(temp,Slope_NOC.deg.K,intercept_NOC.deg.K) { Slope_NOC.deg.K * temp + intercept_NOC.deg.K  }
    # CUE
    T_correct.CUE <- function(temp,Slope_CUE,intercept_CUE){ Slope_CUE * temp + intercept_CUE } 
    #breakdown coefficient of DOC
    T_correct.above0.P.DOC <- function(temp,Slope_above0.P.DOC,intercept_P.DOC){ Slope_above0.P.DOC * temp + intercept_P.DOC } 
    #breakdown coefficient of SOC
    T_correct.above0.P.NOC <- function(temp,Slope_above0.P.NOC,intercept_P.NOC){ Slope_above0.P.NOC * temp + intercept_P.NOC } 
    #sorption
    T_correct.C.sor1 <- function(temp,Slope_C.sor1,intercept_C.sor1){ Slope_C.sor1 * temp + intercept_C.sor1 } 
    T_correct.C.sor2 <- function(temp,Slope_C.sor2,intercept_C.sor2){ Slope_C.sor2 * temp + intercept_C.sor2 } 
    #desorption
    T_correct.r1 <- function(temp,Slope_r1,intercept_r1){ Slope_r1 * temp + intercept_r1 } 
    T_correct.r2 <- function(temp,Slope_r2,intercept_r2){ Slope_r2 * temp + intercept_r2 } 
    #dormancy
    T_correct <- function(temp){ifelse(temp < 0, 0, 1)}
    #For freeze death
    T_correct.ice <- function(temp){ifelse(temp < 0, 1, 0)}
    #For aggregate break release
    T_correct_increase <- function(temp) {
      dtemp <- c(0, diff(temp))
      mark <- ifelse(temp >= 0 & temp <= 10 & dtemp > 0, 1, 0)
      return(mark)
    }
  }
  
  Model.base.T2 <- function(x,MB0,DOC0,CUE10) {
    #parameter inputs
    {
      ###
      T0 <-  1e+6			        # Total SOC unit: 10^6 micrograms == 1 g
      gas <- 8.314
      
      
      ### 
      M0	<- 	MB0		 # microbial biomass carbon (measured value)
      f.enz <- .02   # initial enzyme ratio #set to 2% ###same for the four cycles of the same soil###
      Enz0 <-  M0 * f.enz      # initial enzyme value (assumed to be half of microbial biomass carbon)
      C0 	<-	T0 - MB0 - Enz0	 # carbon excluding microbes and enzymes, i.e., DOC + SOC
      # ratio of protected DOC to available DOC
      f.A.DOC_P.DOC <- 0.5 # A.DOC #set to 40-60% ###same for the four cycles of the same soil###
      P.DOC.0 <- DOC0 * (1-f.A.DOC_P.DOC)  #protected DOC content
      A.DOC.0 <- DOC0 * f.A.DOC_P.DOC  #available DOC content
      # fraction of protected recalcitrant carbon
      f.P.NOC <- 0.5  ###same for the four cycles of the same soil###
      P.NOC.0 <- (C0 -  DOC0)*(f.P.NOC)   #protected recalcitrant carbon content
      A.NOC.0 <- (C0 -  DOC0)*(1-f.P.NOC) #available recalcitrant carbon content
      
      #higher temperature promotes desorption
      #lower temperature promotes sorption
      ### DOC sorption
      C.sor1.10 <- x[1] 
      C.sor1.minus10 <- x[2]
      intercept_C.sor1 <- (C.sor1.10 + C.sor1.minus10)/2 # sorption coefficient
      Slope_C.sor1 <- (C.sor1.10 - C.sor1.minus10)/20    # 
      ### SOC sorption
      C.sor2.10 <- x[3] 
      C.sor2.minus10 <- x[4]
      intercept_C.sor2 <- (C.sor2.10 + C.sor2.minus10)/2 # sorption coefficient
      Slope_C.sor2 <- (C.sor2.10 - C.sor2.minus10)/20    # 
      ### DOC desorption
      r1.10 <- x[5] 
      r1.minus10 <- x[6] 
      intercept_r1 <- (r1.10 + r1.minus10)/2 # desorption coefficient
      Slope_r1 <- (r1.10 - r1.minus10)/20    # desorption coefficient
      ### SOC desorption
      r2.10 <- x[7]
      r2.minus10 <- x[8] 
      intercept_r2 <- (r2.10 + r2.minus10)/2 # desorption coefficient
      Slope_r2 <- (r2.10 - r2.minus10)/20    # desorption coefficient
      
      ###
      V <- exp(x[9:10])  # maximum rate of microbial DOC uptake / maximum rate of enzyme NOC degradation
      DOC.uptake.Ea <- 47 # activation energy for microbial DOC uptake
      NOC.deg.Ea 	 <-	47 	# activation energy for enzyme NOC degradation
      f  <-	 .2           # fraction of dead microbial biomass converted to DOC
      
      #from -10 to 10 degrees, Km decreases as temperature rises and activity increases
      ###MBC uptake of DOC
      DOC.uptake.K.10 <- A.DOC.0*0.2 ###same for the four cycles of the same soil set to 45-55%###
      DOC.uptake.K.minus10 <- A.DOC.0*0.8 ###same for the four cycles of the same soil set to 55-60%###
      intercept_DOC.uptake.K <- (DOC.uptake.K.10+DOC.uptake.K.minus10)/2 # intercept of microbial DOC uptake half-saturation constant
      Slope_DOC.uptake.K <- (DOC.uptake.K.10-DOC.uptake.K.minus10)/20    # slope of microbial DOC uptake half-saturation constant
      ###Enz degradation of NOC
      NOC.deg.K.10 <- A.NOC.0*0.2 ###same for the four cycles of the same soil set to 45-55%###
      NOC.deg.K.minus10 <- A.NOC.0*0.8 ###same for the four cycles of the same soil set to 55-60%###
      intercept_NOC.deg.K <- (NOC.deg.K.10+NOC.deg.K.minus10)/2    # intercept of enzyme NOC degradation
      Slope_NOC.deg.K <- (NOC.deg.K.10-NOC.deg.K.minus10)/20       # slope of enzyme NOC degradation
      #enzyme death
      Enz.D <- exp(x[11])
      #microbial physiological mortality
      MBC.D <- exp(x[12])
      #microbial enzyme production
      Enz.P <- exp(x[13])
      #microbial CUE
      CUE.10 <- CUE10       #based on measured value ###same for the four cycles of the same soil###
      CUE.minus10 <- x[14]  
      intercept_CUE <- (CUE.10+CUE.minus10)/2
      Slope_CUE <- (CUE.10-CUE.minus10)/20
      
      #physical mechanism
      f1 <- 0   # below 0 degrees, A.DOC isolation coefficient set to 40-60%  
      f2 <- f1   # below 0 degrees, A.SOC isolation coefficient set to 40-60%  
      #intercept of protected DOC breakdown coefficient
      intercept_P.DOC <- 0
      #calculate slope from intercept
      Slope_above0.P.DOC <- -(intercept_P.DOC/10)
      #intercept of protected NOC breakdown coefficient
      intercept_P.NOC <- 0
      #calculate slope from intercept
      Slope_above0.P.NOC <- -(intercept_P.NOC/10)
      
      #physiological mechanism
      dormancy.ratio <- 0  # microbial dormancy ratio
      inactive.ratio <- 0  # enzyme inactive ratio
      # microbial freeze-death ratio due to water freezing
      MBC.D.ice <- 0
      
    } 
    #data frame for all data
    {     
      timesteps <- length(LFLT_stage123$temp)
      Cpools <- matrix(0, nrow = timesteps, ncol = 18)
      colnames(Cpools) <- c("Hour","Temp",
                            "MBC","MBC1","MBC2",
                            "Enz","Enz1","Enz2",
                            "P.DOC","P.NOC",
                            "DOC1","DOC2","DOC",
                            "NOC1","NOC2","NOC",
                            "MBC_R","Enz.deg")
      Cpools[, "Hour"] <- LFLT_stage123$time
      Cpools[, "Temp"] <- LFLT_stage123$temp
    }
    #initial values
    {
      Cpools[1,'MBC'] <- M0
      Cpools[1,'MBC1'] <- M0 * (1-dormancy.ratio)
      Cpools[1,'MBC2'] <- M0 * dormancy.ratio
      Cpools[1,'Enz'] <- Enz0
      Cpools[1,'Enz1'] <- Enz0 * (1-inactive.ratio)
      Cpools[1,'Enz2'] <- Enz0 * inactive.ratio
      Cpools[1,'P.DOC'] <- P.DOC.0 
      Cpools[1,'P.NOC'] <- P.NOC.0
      Cpools[1,'DOC1'] <- A.DOC.0 * (1-f1) 
      Cpools[1,'DOC2'] <- A.DOC.0 * f1 
      Cpools[1,'DOC'] <- A.DOC.0 + P.DOC.0  
      Cpools[1,'NOC1'] <- A.NOC.0 * (1-f2) 
      Cpools[1,'NOC2'] <- A.NOC.0 * f2
      Cpools[1,'NOC'] <- A.NOC.0 + P.NOC.0
      Cpools[1,'MBC_R'] <- 0
      Cpools[1,'Enz.deg'] <- 0
      
    }
    #vectorize parameters to avoid repeated computation
    {
      DOC.uptake.K_vec <- T_correct.DOC.uptake.K(LFLT_stage123$temp,Slope_DOC.uptake.K,intercept_DOC.uptake.K)
      NOC.deg.K_vec <- T_correct.NOC.deg.K(LFLT_stage123$temp,Slope_NOC.deg.K,intercept_NOC.deg.K)
      CUE_vec <- T_correct.CUE(LFLT_stage123$temp,Slope_CUE,intercept_CUE)
      Csor1_vec <- T_correct.C.sor1(LFLT_stage123$temp,Slope_C.sor1,intercept_C.sor1)
      Csor2_vec <- T_correct.C.sor2(LFLT_stage123$temp,Slope_C.sor2,intercept_C.sor2)
      r1_vec <- T_correct.r1(LFLT_stage123$temp,Slope_r1,intercept_r1)
      r2_vec <- T_correct.r2(LFLT_stage123$temp,Slope_r2,intercept_r2)
      P.DOC.above0_vec <-  T_correct.above0.P.DOC(LFLT_stage123$temp,Slope_above0.P.DOC,intercept_P.DOC)
      P.NOC.above0_vec <-  T_correct.above0.P.NOC(LFLT_stage123$temp,Slope_above0.P.NOC,intercept_P.NOC)
      temp.cor_vec <- T_correct(LFLT_stage123$temp)     
      temp.cor.ice_vec <- T_correct.ice(LFLT_stage123$temp)     
      temp.cor.increase_vec <- T_correct_increase(LFLT_stage123$temp)
    }
    #process
    for (jj in 1:(timesteps-1)){ 
      #prepare temperature-related coefficients
      {
        temp <- LFLT_stage123$temp[jj] #start from the second row
        #microbial DOC uptake half-saturation constant (temperature-dependent)
        DOC.uptake.K <- DOC.uptake.K_vec[jj]
        #enzyme NOC degradation half-saturation constant (temperature-dependent)
        NOC.deg.K <- NOC.deg.K_vec[jj]
        #microbial CUE (temperature-dependent)
        CUE <- CUE_vec[jj]
        #DOC and SOC sorption
        Csor1 <- Csor1_vec[jj]
        Csor2 <- Csor2_vec[jj]
        #P.DOC and P.SOC desorption
        r1 <- r1_vec[jj]
        r2 <- r2_vec[jj]
        #protected DOC breakdown coefficient
        P.DOC.above0 <- P.DOC.above0_vec[jj]
        #protected NOC breakdown coefficient
        P.NOC.above0 <- P.NOC.above0_vec[jj]
        #for dormant microbes, inactive enzymes, and physical isolation; set to 0 below 0 degrees
        temp.cor <- temp.cor_vec[jj]
        #for microbes killed by freezing; set to 1 below 0 degrees and 0 above 0 degrees
        temp.cor.ice <- temp.cor.ice_vec[jj]
        #aggregate breakdown during thawing
        temp.cor.increase <- temp.cor.increase_vec[jj]
      }
      #iteration
      #substitute the defined parameters
      #accumulate change metrics
      MBC1=Cpools[jj,'MBC1'] 
      MBC2=Cpools[jj,'MBC2'] 
      Enz1=Cpools[jj,'Enz1'] 
      Enz2=Cpools[jj,'Enz2'] 
      DOC1=Cpools[jj,'DOC1'] 
      DOC2=Cpools[jj,'DOC2'] 
      DOC=Cpools[jj,'DOC'] 
      NOC1=Cpools[jj,'NOC1'] 
      NOC2=Cpools[jj,'NOC2'] 
      NOC=Cpools[jj,'NOC'] 
      P.DOC=Cpools[jj,'P.DOC'] 
      P.NOC=Cpools[jj,'P.NOC'] 
      
      deltaC = Flux_all(
        V=V,temp=temp,
        DOC.uptake.K=DOC.uptake.K,
        DOC.uptake.Ea=DOC.uptake.Ea,
        Enz.P=Enz.P,
        Enz.D=Enz.D,
        MBC.D=MBC.D,
        MBC.D.ice=MBC.D.ice,
        NOC.deg.K=NOC.deg.K,
        NOC.deg.Ea=NOC.deg.Ea,
        gas=gas,
        Csor1=Csor1,Csor2=Csor2,
        r1=r1,r2=r2,
        CUE=CUE,f=f,f1=f1,f2=f2,
        P.DOC.above0,P.NOC.above0,
        MBC1=MBC1,MBC2=MBC2,
        Enz1=Enz1,Enz2=Enz2,
        DOC1=DOC1,DOC2=DOC2,
        NOC1=NOC1,NOC2=NOC2,
        P.DOC=P.DOC,P.NOC=P.NOC,
        temp.cor=temp.cor,
        temp.cor.ice=temp.cor.ice,
        temp.cor.increase=temp.cor.increase
      )		
      deltaC <- as.numeric(deltaC)
      
      Cpools[jj+1,3] = Cpools[jj,3] + deltaC[1] #MBC
      Cpools[jj+1,4] = Cpools[jj,4] + deltaC[2] #MBC1
      Cpools[jj+1,5] = Cpools[jj,5] + deltaC[3] #MBC2
      Cpools[jj+1,6] = Cpools[jj,6] + deltaC[4] #Enz
      Cpools[jj+1,7] = Cpools[jj,7] + deltaC[5] #Enz1
      Cpools[jj+1,8] = Cpools[jj,8] + deltaC[6] #Enz2
      Cpools[jj+1,9] = Cpools[jj,9] + deltaC[7] #P.DOC
      Cpools[jj+1,10] =  Cpools[jj,10] + deltaC[8] #P.NOC   
      Cpools[jj+1,11] =  Cpools[jj,11] + deltaC[9]  #DOC1
      Cpools[jj+1,12] =  Cpools[jj,12] + deltaC[10] #DOC2
      Cpools[jj+1,13] =  Cpools[jj,13] + deltaC[11] #DOC
      Cpools[jj+1,14] =  Cpools[jj,14] + deltaC[12] #NOC1
      Cpools[jj+1,15] =  Cpools[jj,15] + deltaC[13] #NOC2
      Cpools[jj+1,16] =  Cpools[jj,16] + deltaC[14] #NOC
      Cpools[jj+1,17] = deltaC[15] #MBC_R
      Cpools[jj+1,18] = deltaC[16] #Enz.deg
    }
    return(Cpools)
  }

} 


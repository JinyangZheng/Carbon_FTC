
###
### Carbon_FTC_Fig.5
###

{
  ###
  ### R2
  ###
  {
    ###R2_LFLT
    {
  
      R2_LFLT <-
        ggplot(R2_LFLT,aes(time.point,R2))+
        geom_line()+
        geom_ribbon(
          aes(ymin=low,
              ymax=high,fill="black"),
          alpha=0.5)+
        scale_x_continuous(breaks = c(0,48,96,192,240)
        )+labs(x='Incubation days',y='R2')
    }
    ###R2_LFST
    {
     R2_LFST <-
        ggplot(R2_LFST,aes(time.point,R2))+
        geom_line()+
        geom_ribbon(
          aes(ymin=low,
              ymax=high,fill="black"),
          alpha=0.5)+
        scale_fill_manual(values = c("1" = "#eea9be", "2" = "#6a96e1")) +
        scale_x_continuous(breaks = c(0,48,96,192,240)
        )+labs(x='Incubation days',y='R2')
    }
    ###R2_SFLT
    {
   
      R2_SFLT <-
        ggplot(R2_SFLT,aes(time.point,R2))+
        geom_line()+
        geom_ribbon(
          aes(ymin=low,
              ymax=high,fill="black"),
          alpha=0.5)+
        scale_fill_manual(values = c("1" = "#eea9be", "2" = "#6a96e1")) +
        scale_x_continuous(breaks = c(0,48,96,192,240)
        )+labs(x='Incubation days',y='R2')
    } 
    ###R2_SFST
    {
     R2_SFST <-
        ggplot(R2_SFST,aes(time.point,R2))+
        geom_line()+
        geom_ribbon(
          aes(ymin=low,
              ymax=high,fill="black"),
          alpha=0.5)+
       scale_fill_manual(values = c("1" = "#eea9be", "2" = "#6a96e1")) +
       scale_x_continuous(breaks = c(0,48,96,192,240)
        )+labs(x='Incubation days',y='R2')
    }
  }
  ### Physical protection: fisolation  BDOCp
  ###
  ### LFLT
  {
    
    
    bg_cols <- c("1" = "#eea9be", "2" = "#6a96e1")
    var_cols <- c(
      "BDOCp"          = "#e994ae",
       "fisolation"     = "#41B6C4",
  
    )

    LFLT.physical <- 
      ggplot(select.frame.shap., 
             aes(x=timepoint.LFLT, y=value,
                 colour = variable)) +
      geom_line( linewidth = 0.8) +
      geom_ribbon(aes(ymin = low,
                      ymax = high,
                      fill=variable),
                  alpha = 0.1,
                  colour = NA,  
                  show.legend = FALSE) +
      scale_fill_manual(values = var_cols) +     
      scale_color_manual(values = var_cols) +    
      coord_cartesian(ylim=c(0,60)) +
      scale_y_continuous(breaks = c(0,25,50))+
      scale_x_continuous(breaks = c(0,48,96))+ #,labels = c(7.9,8.9,9.9,10.9)
      labs(x='Incubation days', y='Relative importance (%)')
    
  }
  ###LFST
  {
    
    LFST.physical <- 
      ggplot(select.frame.shap., 
             aes(x=timepoint.LFST, y=value,
                 colour = variable)) +
     
      geom_line( linewidth = 0.8) +
      geom_ribbon(aes(ymin = low,
                      ymax = high,
                      fill=variable),
                  alpha = 0.1,
                  colour = NA,  
                  show.legend = FALSE) +
      scale_fill_manual(values = var_cols) +   
      scale_color_manual(values = var_cols) +  
      coord_cartesian(ylim=c(0,60)) +
      scale_y_continuous(breaks = c(0,25,50))+
      scale_x_continuous(breaks = c(0,48,96))+ 
      labs(x='Incubation days', y='Relative importance (%)')
    
    
  }
  ###SFLT
  {
    SFLT.physical <- 
      ggplot(select.frame.shap., 
             aes(x=timepoint.SFLT, y=value,
                 colour = variable)) +
      geom_line( linewidth = 0.8) +
      geom_ribbon(aes(ymin = low,
                      ymax = high,
                      fill=variable),
                  alpha = 0.1,
                  colour = NA,  
                  show.legend = FALSE) +
      scale_fill_manual(values = var_cols) +       
      scale_color_manual(values = var_cols) +      
      coord_cartesian(ylim=c(0,60)) +
      scale_y_continuous(breaks = c(0,25,50))+
      scale_x_continuous(breaks = c(0,48,96))+ 
      labs(x='Incubation days', y='Relative importance (%)')
    
    
    
    
  }
  ###SFST
  {
    SFST.physical <- 
      ggplot(select.frame.shap., 
             aes(x=timepoint.SFST, y=value,
                 colour = variable)) +
      geom_line( linewidth = 0.8) +
      geom_ribbon(aes(ymin = low,
                      ymax = high,
                      fill=variable),
                  alpha = 0.1,
                  colour = NA,  
                  show.legend = FALSE) +
      scale_fill_manual(values = var_cols) +   
      scale_color_manual(values = var_cols) +  
      coord_cartesian(ylim=c(0,60)) +
      scale_y_continuous(breaks = c(0,25,50))+
      scale_x_continuous(breaks = c(0,48,96))+ 
      labs(x='Incubation days', y='Relative importance (%)')
    
  }
  ### Physiology:  fdormancy rfreeze.death V1
  ### LFLT
  {
    
    var_cols <- c(
      "fdormancy"     = "#6a96e1",
      "rfreeze.death" = "#253494",
      "V1"             = "#f1aa7b",
    )
    
    LFLT.physiology <- 
      ggplot(select.frame.shap., 
             aes(x=timepoint.LFLT, y=value,
                 colour = variable)) +
      geom_line( linewidth = 0.8) +
      geom_ribbon(aes(ymin = low,
                      ymax = high,
                      fill=variable),
                  alpha = 0.1,
                  colour = NA,  
                  show.legend = FALSE) +
      scale_fill_manual(values = var_cols) +  
      scale_color_manual(values = var_cols) + 
      coord_cartesian(ylim=c(0,60)) +
      scale_y_continuous(breaks = c(0,25,50))+
      scale_x_continuous(breaks = c(0,48,96))+
     labs(x='Incubation days', y='Relative importance (%)')
    
  }
  ###LFST
  {

    LFST.physiology <- 
      ggplot(select.frame.shap., 
             aes(x=timepoint.LFST, y=value,
                 colour = variable)) +
      geom_line( linewidth = 0.8) +
      geom_ribbon(aes(ymin = low,
                      ymax = high,
                      fill=variable),
                  alpha = 0.1,
                  colour = NA,  
                  show.legend = FALSE) +
      scale_fill_manual(values = var_cols) +   
      scale_color_manual(values = var_cols) +  
      coord_cartesian(ylim=c(0,60)) +
      scale_y_continuous(breaks = c(0,25,50))+
      scale_x_continuous(breaks = c(0,48,96))+ 
      labs(x='Incubation days', y='Relative importance (%)')
    
    
  }
  ###SFLT
  {
    
    SFLT.physiology <- 
      ggplot(select.frame.shap., 
             aes(x=timepoint.SFLT, y=value,
                 colour = variable)) +
      geom_line( linewidth = 0.8) +
      geom_ribbon(aes(ymin = low,
                      ymax = high,
                      fill=variable),
                  alpha = 0.1,
                  colour = NA,  
                  show.legend = FALSE) +
      scale_fill_manual(values = var_cols) +            
      scale_color_manual(values = var_cols) +           
      coord_cartesian(ylim=c(0,60)) +
      scale_y_continuous(breaks = c(0,25,50))+
      scale_x_continuous(breaks = c(0,48,96))+
      labs(x='Incubation days', y='Relative importance (%)')
    
  }
  ###SFST
  {
    
    SFST.physiology <- 
      ggplot(select.frame.shap., 
             aes(x=timepoint.SFST, y=value,
                 colour = variable)) +
      geom_line( linewidth = 0.8) +
      geom_ribbon(aes(ymin = low,
                      ymax = high,
                      fill=variable),
                  alpha = 0.1,
                  colour = NA,  
                  show.legend = FALSE) +
      scale_fill_manual(values = var_cols) +   
      scale_color_manual(values = var_cols) +  
      coord_cartesian(ylim=c(0,60)) +
      scale_y_continuous(breaks = c(0,25,50))+
      scale_x_continuous(breaks = c(0,48,96))+ 
      labs(x='Incubation days', y='Relative importance (%)')
  }
  ###
  ### Physical , physiological and carbon groups
  ### 
  {
    ###LFLT
    {
    
      bg_cols <- c("1" = "#eea9be", "2" = "#6a96e1")
      var_cols <- c(
        
        "Physical properties"     = "#f3bece",
        "Physiological properties"     = "#a0bff6",
        "Carbon pool"            = "#afd1af"
        
        
      )
     
      global.shap.LFLT.plot.group <- 
        ggplot(select.frame.shap., aes(x=timepoint.LFLT, y=value,
                                       color=type,
                                       fill=type
                                       
        )) +
        geom_ribbon(aes(ymin = low,
                        ymax = high,
                        fill = type),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        geom_line(aes(color = type), linewidth = 0.7) +
        scale_fill_manual(values = var_cols) +  
        scale_color_manual(values = var_cols) + 
        coord_cartesian(ylim=c(0,120)
        ) +
        scale_x_continuous(breaks = c(0,48,96))+
        scale_y_continuous(breaks = c(0,50,100))+
        labs(x='Incubation days', y='Relative importance (%)')
    }
    ###LFST
    {
      
      global.shap.LFST.plot.group <- 
        ggplot(select.frame.shap., aes(x=timepoint.LFST, y=value,
                                       color=type,
                                       fill=type
                                       
        )) +
        geom_ribbon(aes(ymin = low,
                        ymax = high,
                        fill = type),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        geom_line(aes(color = type), linewidth = 0.7) +
        scale_fill_manual(values = var_cols) +
        scale_color_manual(values = var_cols) +
        coord_cartesian(ylim=c(0,120)) +
        scale_x_continuous(breaks = c(0,48,96))+
        scale_y_continuous(breaks = c(0,50,100))+
        labs(x='Incubation days', y='Relative importance (%)')
    }
    ###SFLT
    {
      
    global.shap.SFLT.plot.group <- 
        ggplot(select.frame.shap., aes(x=timepoint.SFLT, y=value,
                                       color=type,
                                       fill=type
                                       
        )) +
        geom_ribbon(aes(ymin = low,
                        ymax = high,
                        fill = type),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        geom_line(aes(color = type), linewidth = 0.7) +
        scale_fill_manual(values = var_cols) +      
        scale_color_manual(values = var_cols) +             
        coord_cartesian(ylim=c(0,120)) +
        scale_x_continuous(breaks = c(0,48,96))+ 
        scale_y_continuous(breaks = c(0,50,100))+
        labs(x='Incubation days', y='Relative importance (%)')
    }
    ###SFST
    {
      global.shap.SFST.plot.group <- 
        ggplot(select.frame.shap., aes(x=timepoint.SFST, y=value,
                                       color=type,
                                       fill=type)) +
        geom_ribbon(aes(ymin = low,
                        ymax = high,
                        fill = type),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        geom_line(aes(color = type), linewidth = 0.7) +
        scale_fill_manual(values = var_cols) + 
        scale_color_manual(values = var_cols) +
        coord_cartesian(ylim=c(0,120)) +
        scale_x_continuous(breaks = c(0,48,96))+
        scale_y_continuous(breaks = c(0,50,100))+
        labs(x='Incubation days', y='Relative importance (%)')
    }
    
  }
  ### Output of Fig.5
  ### fisolation fdormancy rfreeze.death V1 BDOCp
  ### physical physiological carbon
  {
    plot_all <- ggarrange(
      
      R2_LFLT,
      R2_LFST,
      R2_SFLT,
      R2_SFST,
      
      LFLT.physical,
      LFST.physical,
      SFLT.physical,
      SFST.physical,
      
      LFLT.physiology,
      LFST.physiology,
      SFLT.physiology,
      SFST.physiology,
      
      global.shap.LFLT.plot.group,
      global.shap.LFST.plot.group,
      global.shap.SFLT.plot.group,
      global.shap.SFST.plot.group,
      ncol=4,nrow=4,align='hv')
    
    ggsave('./Fig_5.pdf',plot_all,dpi=300,width=5.5*4.5, height=4.2*2.8)
  }
}

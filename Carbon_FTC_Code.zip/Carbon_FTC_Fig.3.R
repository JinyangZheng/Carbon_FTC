###
### Carbon_FTC_Fig.3
###

### 2400 m 0-10 cm
{
  ### Temporal dynamic plots for Cal and val plot (Show 2400 m 0-10 cm LFLT) 
  {
    ### MBC_R
    {

      ###plot
      four_Model.MBC_R..2400.10.LFLT <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
        
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val
                   ),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0, 240*24), ylim = c(0, 8.2)) +
        scale_x_continuous(breaks = c(0, 48*24, 96*24, 192*24, 240*24),
                           labels = c(0, 48, 96, 192, 240)) +
        scale_y_continuous(breaks = c(1, 4, 7)) +
         
        labs(x = "Incubation day",
             y = "SOC mineralization rate (ug CO2-C g-1 SOC h-1)",
             color = "Model")
    }
    ### Enz.deg
    {
   
      ###plot
      four_Model.Enz.deg..2400.10.LFLT <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
       
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24) , ylim=c(0,0.7)
        ) +
        scale_x_continuous(breaks = c(0,48*24,96*24,192*24,240*24) ,labels = c(0,48,96,192,240)
        )+
        scale_y_continuous(breaks = c(0.1,0.4,0.7))+
       
        labs(x = 'Incubation day',
             y = 'EEA (ug C g-1 SOC h-1)',
             color = "FTC type") 
    }
    ### DOC
    {
    
      ###plot
      four_Model.DOC..2400.10.LFLT <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
        
       
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24) , 
                        ylim=c(8000,25000)
        ) +
        scale_x_continuous(breaks = c(0,48*24,96*24,192*24,240*24) ,labels = c(0,48,96,192,240)
        )+
        scale_y_continuous(breaks = c(10000,16000,23000))+
        
        labs(x = 'Incubation day',
             y = 'DOC (ug DOC-C g-1 SOC)',
             color = "FTC type") 
      
    }
    ### MBC
    {
 
      ###plot
      four_Model.MBC..2400.10.LFLT <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
       
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24), 
                        ylim=c(2000,20000)
        ) +
        scale_x_continuous(breaks = c(0,96*24,192*24) ,labels = c(0,96,192)
        )+
        scale_y_continuous(breaks = c(4000,11000,18000))+
        
        labs(x = 'Incubation day',
             y = 'MBC (ug MBC-C g-1 SOC)',
             color = "FTC type") 
      
      
    }
  }
  ### Temporal dynamic plots for Cal and val plot (Show 2400 m 0-10 cm LFST) 
  {
    ### MBC_R
    {
   
      ###plot
      four_Model.MBC_R..2400.10.LFST <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
      
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0, 240*24), ylim = c(0, 8.2)) +
        scale_x_continuous(breaks = c(0, 48*24, 96*24, 192*24, 240*24),
                           labels = c(0, 48, 96, 192, 240)) +
        scale_y_continuous(breaks = c(1, 4, 7)) +
        
        labs(x = "Incubation day",
             y = "SOC mineralization rate (ug CO2-C g-1 SOC h-1)",
             color = "Model")
      
    }
    ### Enz.deg
    {
    
      ###plot
      four_Model.Enz.deg..2400.10.LFST <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
       
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24) , ylim=c(0,0.7)
        ) +
        scale_x_continuous(breaks = c(0,48*24,96*24,192*24,240*24) ,labels = c(0,48,96,192,240)
        )+
        scale_y_continuous(breaks = c(0.1,0.4,0.7))+
        
        labs(x = 'Incubation day',
             y = 'EEA (ug C g-1 SOC h-1)',
             color = "FTC type") 
    }
    ### DOC
    {
      
      ###plot
      four_Model.DOC..2400.10.LFST <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
     
        
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24) , 
                        ylim=c(8000,25000)
        ) +
        scale_x_continuous(breaks = c(0,48*24,96*24,192*24,240*24) ,labels = c(0,48,96,192,240)
        )+
        scale_y_continuous(breaks = c(10000,16000,23000))+
        
        labs(x = 'Incubation day',
             y = 'DOC (ug DOC-C g-1 SOC)',
             color = "FTC type") 
      
    }
    ### MBC
    {
      
      ###plot
      four_Model.MBC..2400.10.LFST <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
      
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24), 
                        ylim=c(2000,20000)
        ) +
        scale_x_continuous(breaks = c(0,96*24,192*24) ,labels = c(0,96,192)
        )+
        scale_y_continuous(breaks = c(4000,11000,18000))+
        
        labs(x = 'Incubation day',
             y = 'MBC (ug MBC-C g-1 SOC)',
             color = "FTC type") 
      
      
    }
  }
  ### Temporal dynamic plots for Cal and val plot (Show 2400 m 0-10 cm SFLT) 
  {
    ### MBC_R
    {
      
   
      ###plot
      four_Model.MBC_R..2400.10.SFLT <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
      
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0, 240*24), ylim = c(0, 8.2)) +
        scale_x_continuous(breaks = c(0, 48*24, 96*24, 192*24, 240*24),
                           labels = c(0, 48, 96, 192, 240)) +
        scale_y_continuous(breaks = c(1, 4, 7)) +
        
        labs(x = "Incubation day",
             y = "SOC mineralization rate (ug CO2-C g-1 SOC h-1)",
             color = "Model")
      
    }
    ### Enz.deg
    {
      
      ###plot
      four_Model.Enz.deg..2400.10.SFLT <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
       
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24) , ylim=c(0,0.7)
        ) +
        scale_x_continuous(breaks = c(0,48*24,96*24,192*24,240*24) ,labels = c(0,48,96,192,240)
        )+
        scale_y_continuous(breaks = c(0.1,0.4,0.7))+
       
        labs(x = 'Incubation day',
             y = 'EEA (ug C g-1 SOC h-1)',
             color = "FTC type") 
      
    }
    ### DOC
    {
     
      ###plot
      four_Model.DOC..2400.10.SFLT <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
      
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24) , 
                        ylim=c(8000,25000)
        ) +
        scale_x_continuous(breaks = c(0,48*24,96*24,192*24,240*24) ,labels = c(0,48,96,192,240)
        )+
        scale_y_continuous(breaks = c(10000,16000,23000))+
        
        labs(x = 'Incubation day',
             y = 'DOC (ug DOC-C g-1 SOC)',
             color = "FTC type") 
    }
    ### MBC
    {
      
      ###plot
      four_Model.MBC..2400.10.SFLT <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
        
        
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24), 
                        ylim=c(2000,20000)
        ) +
        scale_x_continuous(breaks = c(0,96*24,192*24) ,labels = c(0,96,192)
        )+
        scale_y_continuous(breaks = c(4000,11000,18000))+
       
        labs(x = 'Incubation day',
             y = 'MBC (ug MBC-C g-1 SOC)',
             color = "FTC type") 
      
      
    }
  }
  ### Temporal dynamic plots for Cal and val plot (Show 2400 m 0-10 cm SFST) 
  {
    ### MBC_R 
    {
     
      ###plot
      four_Model.MBC_R..2400.10.SFST <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
        
       
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0, 240*24), ylim = c(0, 8.2)) +
        scale_x_continuous(breaks = c(0, 48*24, 96*24, 192*24, 240*24),
                           labels = c(0, 48, 96, 192, 240)) +
        scale_y_continuous(breaks = c(1, 4, 7)) +
         
         
           
         
        labs(x = "Incubation day",
             y = "SOC mineralization rate (ug CO2-C g-1 SOC h-1)",
             color = "Model")
      
      
    }
    ### Enz.deg
    {
     
      ###plot
      four_Model.Enz.deg..2400.10.SFST <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
       
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24) , ylim=c(0,0.7)
        ) +
        scale_x_continuous(breaks = c(0,48*24,96*24,192*24,240*24) ,labels = c(0,48,96,192,240)
        )+
        scale_y_continuous(breaks = c(0.1,0.4,0.7))+
         
        
        labs(x = 'Incubation day',
             y = 'EEA (ug C g-1 SOC h-1)',
             color = "FTC type") 
      
      
    }
    ### DOC
    {
     
      ###plot
      four_Model.DOC..2400.10.SFST <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
        
        
        
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24) , 
                        ylim=c(8000,25000)
        ) +
        scale_x_continuous(breaks = c(0,48*24,96*24,192*24,240*24) ,labels = c(0,48,96,192,240)
        )+
        scale_y_continuous(breaks = c(10000,16000,23000))+
         
       
        labs(x = 'Incubation day',
             y = 'DOC (ug DOC-C g-1 SOC)',
             color = "FTC type") 
    }
    ### MBC
    {
      
   
      ###plot
      four_Model.MBC..2400.10.SFST <- 
        ggplot(line., aes(x = Hour, y = mean,
                          color = Model,
                          group = Model)) +
        
     
        ggnewscale::new_scale_fill() +
        
        geom_ribbon(aes(ymin = mean - sd,
                        ymax = mean + sd,
                        fill = Model),
                    alpha = 0.25,
                    colour = NA,
                    show.legend = FALSE) +
        
        scale_fill_manual(values = c("Base"   = "#e4c8ff",
                                     "Physio" = "#8baade",
                                     "Physic" = "#f0b4c6",
                                     "Full"   = "#9ed69e"),
                          guide = "none") +
        
        geom_vline(xintercept = 4608,
                   linetype = "dashed",
                   color = "grey60",
                   linewidth = 1) +
        
        geom_line(linewidth = 0.9) +
        
        geom_point(data = point,
                   aes(x = Hour, y = value, shape = cal.val),
                   size = 4, stroke = 0.8,
                   color = "grey40", alpha = 0.4) +
        
        scale_shape_manual(values = c("cal" = 1, "val" = 1)) +
        
        scale_color_manual(values = c("Base"   = "#e4c8ff",
                                      "Physio" = "#8baade",
                                      "Physic" = "#f0b4c6",
                                      "Full"   = "#9ed69e")) +
        
        coord_cartesian(xlim = c(0,240*24), 
                        ylim=c(2000,20000)
        ) +
        scale_x_continuous(breaks = c(0,96*24,192*24) ,labels = c(0,96,192)
        )+
        scale_y_continuous(breaks = c(4000,11000,18000))+
         
         
         
        labs(x = 'Incubation day',
             y = 'MBC (ug MBC-C g-1 SOC)',
             color = "FTC type") 
      
      
    }
  }
  ### 16 plots of temporal MBC_R Enz.deg DOC MBC plots combine 2400 0-10
  {
    plot_all <- ggarrange(
      four_Model.MBC_R..2400.10.LFLT,
      four_Model.MBC_R..2400.10.LFST,
      four_Model.MBC_R..2400.10.SFLT,
      four_Model.MBC_R..2400.10.SFST,
      
      four_Model.Enz.deg..2400.10.LFLT,
      four_Model.Enz.deg..2400.10.LFST,
      four_Model.Enz.deg..2400.10.SFLT,
      four_Model.Enz.deg..2400.10.SFST,
      
      four_Model.DOC..2400.10.LFLT,
      four_Model.DOC..2400.10.LFST,
      four_Model.DOC..2400.10.SFLT,
      four_Model.DOC..2400.10.SFST,
      
      four_Model.MBC..2400.10.LFLT,
      four_Model.MBC..2400.10.LFST,
      four_Model.MBC..2400.10.SFLT,
      four_Model.MBC..2400.10.SFST,
      
      ncol=4,nrow=4,
      align='v')
    
    ggsave('./Fig.3.pdf',plot_all,dpi=300,width=5.8*2.8*1.3, height=5.2*1.8*1.5)
  }
}
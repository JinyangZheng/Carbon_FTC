###
### Carbon_FTC_Fig.4
###

#Fig.4a
{
  Fig.4a <- 
  ggplot(R2.intergated.frame,
         aes(x=type,y=R2.c))+
  geom_vline(xintercept = c(2.5,4.5,5.5,6.5,8.5), linetype = "dashed", color = "grey50", linewidth = 0.5) +
  geom_vline(xintercept = c(1.5,3.5,7.5),  color = "black", linewidth = 0.5) +
  geom_boxplot(position=position_nudge(x=-0.1, y=0),
               outlier.shape = NA,
               width = 0.1,
               alpha = 0.7,
               color='black',
               fill=NA) + 
  geom_half_violin(position=position_nudge(x=0.05, y=0),
                   side='R',
                   adjust=1.2,
                   trim=F,
                   color='black',
                   fill=NA,
                   alpha=1)+
  geom_sina(data=R2.intergated.frame,
            aes(x = type, 
                y = R2.c),  
            position=position_nudge(x=0.05, y=0),
            maxwidth=0.1,
            size = 3.5, 
            shape = 20,
            color = "grey50", 
            alpha=.05)+
  scale_y_continuous(expand = c(0),limits = c(0.84,1.01),breaks = c(0.85,0.93,1))+
  labs(x=NULL,y='R2')
}

#Fig.4b
{
  Fig.4b <- 
      ggplot(plot_data, aes(x=x_names, y=mean, 
                            color=type,fill=type)) +    
      geom_col(position = position_dodge(width = 0.7), 
               width = 0.8) +
      geom_segment(
        aes(x = x_names, xend = x_names, 
            y = low, yend = high),
        linewidth = 0.6,
        color = "black"
      ) +
      geom_text(aes(label = paste0(round(mean,0)),y = high + 3,x=x_names),
                position = position_dodge(width = 0.7),
                size = 5, hjust = 0.5, color = "black") +    
      geom_vline(xintercept = c(7.5,14.5-0.125,17.5,20.5+0.125,27.5), linetype = "dashed", color = "grey50", linewidth = 0.5) +
      geom_vline(xintercept = c(4,11,24),  color = "black", linewidth = 0.5) +
      scale_fill_manual(values = cols) +
      scale_color_manual(values = cols) +
      scale_y_continuous(expand = c(0),limits = c(0,61),breaks = c(0,30,60))+
      scale_x_continuous(expand = c(0.01),limits = c(0.5,30.75),breaks = plot_data$x_names)+
      labs(x=NULL, y=NULL)

  } 

#Fig.4c
{
  cols <- c("Physical parameters" = "#e994ae","Physiological parameters" = "#a0bff6","Carbon pool" = "#afd1af")
  Fig.4c <- 
      ggplot(plot_data, aes(x=x_names, y=mean, 
                            color=type,fill=type)) +    
      geom_col(position = position_dodge(width = 0.7), 
               width = 0.6
      ) +
      geom_segment(
        aes(x = x_names, xend = x_names, 
            y = low, yend = high),
        linewidth = 0.6,
        color = "black"
      ) +
      geom_text(aes(label = paste0(round(mean,0)),y = high + 3,x=x_names),
                position = position_dodge(width = 0.7),
                size = 5, hjust = 0.5, color = "black") +    
      geom_vline(xintercept = c(7.5,14.5-0.125,17.5,20.5+0.125,27.5), linetype = "dashed", color = "grey50", linewidth = 0.5) +
      geom_vline(xintercept = c(4,11,24),  color = "black", linewidth = 0.5) +
      scale_fill_manual(values = cols) +
      scale_color_manual(values = cols) +
      scale_y_continuous(expand = c(0),limits = c(0,140),breaks = c(0,50,100))+
      scale_x_continuous(expand = c(0.01),limits = c(0.5,30.75),breaks = x_names)+
     labs(x=NULL, y=NULL)
    
    
    
  }
